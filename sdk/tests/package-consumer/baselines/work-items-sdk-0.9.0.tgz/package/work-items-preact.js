import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "preact/jsx-runtime";
import { useState } from 'preact/hooks';
import { createTUIApp, useAppLifecycle, useArrayRef, useDataRef, View } from '@aotui/sdk';
import { ItemType, WorkspaceType, initialState, itemRefOptions, label, listRefOptions, otherViewId, selectedViewId, workViewTypes, workspaceText } from './work-items.js';
function Item({ value, items }) {
    const selected = useDataRef('selected', value, itemRefOptions);
    return _jsxs("div", { children: [_jsx("p", { children: selected(items === undefined ? 'Other item' : label) }), items === undefined ? null : _jsx(Items, { values: items })] });
}
function Items({ values }) {
    const [list, element] = useArrayRef('items', values, listRefOptions);
    return _jsxs(_Fragment, { children: [_jsx("p", { children: list('All items') }), values.map((_, index) => _jsx("p", { children: element(index, `Item ${index + 1}`) }, index))] });
}
export function workItemsApp(app_name, options = {}) {
    function WorkItems() {
        const [state, setState] = useState(initialState);
        useAppLifecycle({ stop: () => options.onStop?.(), close: () => options.onClose?.() });
        return _jsxs(_Fragment, { children: [_jsx(View, { id: "workspace", type: WorkspaceType, context: { change: setState, options }, kind: "state", children: _jsx("p", { children: workspaceText(state) }) }), _jsx(View, { id: otherViewId, type: ItemType, context: { change: setState }, kind: "state", children: _jsx(Item, { value: false }) }), state.open && _jsx(View, { id: selectedViewId, type: ItemType, context: { change: setState }, kind: "state", children: _jsx(Item, { value: state.value, items: state.items }) })] });
    }
    return createTUIApp({ app_name, component: WorkItems, viewTypes: workViewTypes });
}
export default workItemsApp('work_items');
