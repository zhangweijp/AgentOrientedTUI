import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { repo, factsFile, facts, working, consumer, modules, apps, start, scope, snapshot, toolNames, viewText, fileView, invoke, close, eventually, runCase } from './ide-test-harness.mjs';

const workspaceTools = ['search_files_by_pattern', 'search_files_by_content', 'multi_open_file', 'multi_close_file', 'create_file',
    'batch_edit', 'multi_open_dirs', 'multi_close_dirs', 'add_folder_to_workspace', 'remove_folder_from_workspace', 'refresh_workspace'];
const fileMutations = ['write_file', 'edit_file', 'delete_file', 'rename_file'];
const languageTools = ['lsp_hover', 'lsp_goto_definition', 'lsp_find_references', 'lsp_get_diagnostics', 'lsp_document_symbol', 'lsp_incoming_calls', 'lsp_outgoing_calls'];
async function inspectTools(app, viewId) {
    const client = scope(app);
    try {
        const observed = await client.observe({ viewIds: [viewId] });
        assert.equal(observed.status, 'observed', JSON.stringify(observed));
        return observed.observation;
    } finally { client.close(); }
}
try {
    const root = path.join(working, 'workspace'), other = path.join(working, 'workspace-sibling');
    await fs.mkdir(path.join(root, 'src'), { recursive: true }); await fs.mkdir(other);
    const file = path.join(root, 'src/main.ts'), second = path.join(root, 'src/second.ts');
    const source = 'export function leaf(value: number): number { return value + 1; }\nexport function caller(): number { return leaf(1); }\nconst broken: number = "wrong";\n';
    await fs.writeFile(file, source); await fs.writeFile(second, 'export const sibling = 7;\n');
    await fs.writeFile(path.join(root, 'tsconfig.json'), JSON.stringify({ compilerOptions: { strict: true }, include: ['src/**/*.ts'] }));
    const a = await start(root, 'a'), b = await start(root, 'b');
    await runCase('workspace discovery, FileDetail-owned mutations, exact range, unique file records, two Apps', async () => {
        const initial = await inspectTools(a, 'workspace');
        assert.deepEqual(initial.tools.map(tool => tool.name).sort(), workspaceTools.filter(name => name !== 'batch_edit').sort());
        assert.equal(snapshot(a).views.filter(view => view.type === 'FileDetail').length, 0);
        for (const name of fileMutations) assert.ok(!toolNames(a).includes(name), name + ' is absent before a file is opened');
        await invoke(a, 'multi_open_file', { filePaths: [file, second, file], offset: 1, limit: 1 });
        const details = snapshot(a).views.filter(view => view.type === 'FileDetail');
        assert.equal(details.length, 2); assert.equal(new Set(details.map(view => view.id)).size, 2);
        for (const detail of details) {
            const observed = await inspectTools(a, detail.id);
            for (const name of fileMutations) {
                const tool = observed.tools.find(tool => tool.name === name); assert.ok(tool, name + ' belongs to the loaded FileDetail');
                assert.deepEqual(tool.targets.map(target => [target.viewId, target.viewInstanceId]), [[detail.id, detail.viewInstanceId]]);
                assert.ok(!Object.hasOwn(tool.inputSchema.properties, 'filePath'));
                assert.ok(!Object.hasOwn(tool.inputSchema.properties, 'oldPath'));
            }
        }
        const workspace = await inspectTools(a, 'workspace');
        assert.deepEqual(workspace.tools.map(tool => tool.name).sort(), [...workspaceTools].sort());
        assert.ok(workspace.tools.some(tool => tool.name === 'batch_edit'), 'Batch editing becomes available after files are loaded');
        assert.match(viewText(a, fileView(a, file).id), /00002\|/); assert.doesNotMatch(viewText(a, fileView(a, file).id), /00001\|/);
        assert.equal(snapshot(b).views.filter(view => view.type === 'FileDetail').length, 0);
        await invoke(a, 'multi_open_dirs', { dirPaths: [path.join(root, 'src')] });
        await invoke(a, 'multi_close_dirs', { dirPaths: [path.join(root, 'src')] });
        await invoke(a, 'refresh_workspace', {}, { changes: false });
        await invoke(a, 'add_folder_to_workspace', { folderPath: other });
        await invoke(a, 'remove_folder_from_workspace', { folderPath: root });
        assert.match(viewText(a, 'workspace'), new RegExp(other));
        await invoke(a, 'add_folder_to_workspace', { folderPath: root });
        await invoke(a, 'multi_open_file', { filePaths: [file, second] });
    });
    await runCase('real TypeScript seven queries, current document changes, readonly diagnostic slice', async () => {
        await invoke(b, 'multi_open_file', { filePaths: [second] });
        const otherApp = await invoke(b, 'lsp_hover', { file_path: second, line: 1, character: 14 }, { view: fileView(b, second).id });
        assert.ok(otherApp.value.data.value); assert.equal(snapshot(b).views.filter(view => view.type === 'FileDetail').length, 1);
        const otherFile = path.join(other, 'other.ts'); await fs.writeFile(otherFile, 'export const otherRoot = "other";\n');
        await invoke(a, 'multi_open_file', { filePaths: [otherFile] });
        assert.ok((await invoke(a, 'lsp_hover', { file_path: otherFile, line: 1, character: 16 }, { view: fileView(a, otherFile).id })).value.data.value);
        let view = fileView(a, file).id;
        const queries = [
            ['lsp_hover', { file_path: file, line: 1, character: 18 }],
            ['lsp_goto_definition', { file_path: file, line: 2, character: 43 }],
            ['lsp_find_references', { file_path: file, line: 1, character: 18 }],
            ['lsp_get_diagnostics', { file_path: file }],
            ['lsp_document_symbol', { file_path: file }],
            ['lsp_incoming_calls', { file_path: file, line: 1, character: 18 }],
            ['lsp_outgoing_calls', { file_path: file, line: 2, character: 18 }],
        ];
        const client = scope(a), observation = (await client.observe({ viewIds: [view] })).observation;
        try {
            for (const [name, args] of queries) {
                const outcome = await invoke(a, name, args, { view, client, observation });
                assert.ok(JSON.stringify(outcome.value.data.value).length > 2, name + ' has a real nonempty result');
            }
        } finally { client.close(); }
        let loaded = await invoke(a, 'read_loaded_diagnostics', {}, { view, changes: false });
        assert.ok(loaded.value.data.diagnostics.some(d => d.code === 2322));
        await invoke(a, 'edit_file', { oldString: '"wrong"', newString: '1' }, { view: fileView(a, file).id });
        view = fileView(a, file).id;
        const fresh = await invoke(a, 'lsp_get_diagnostics', { file_path: file }, { view });
        assert.equal(fresh.value.data.value.some(d => d.code === 2322), false);
        loaded = await invoke(a, 'read_loaded_diagnostics', {}, { view, changes: false });
        assert.equal(loaded.value.data.diagnostics.some(d => d.code === 2322), false);
        await invoke(a, 'lsp_hover', { file_path: second, line: 1, character: 1 }, { view, status: 'failed', changes: false });
    });
    await runCase('search completeness, complete View-owned contracts and optional exclusive creation', async () => {
        await invoke(a, 'search_files_by_pattern', { pattern: '**/*.ts' });
        assert.deepEqual([...new Set(toolNames(a))].sort(), [...workspaceTools, ...fileMutations, ...languageTools,
            'close_file_detail', 'close_search_view', 'read_loaded_diagnostics', 'create_file_if_absent'].sort());
        await invoke(a, 'close_search_view', { view_id: 'search' }, { view: 'search' });
        await invoke(a, 'search_files_by_content', { pattern: 'caller\\(', include: '**/*.ts' });
        const before = viewText(a, 'search');
        await invoke(a, 'search_files_by_content', { pattern: '[' }, { status: 'failed', changes: false });
        assert.equal(viewText(a, 'search'), before);
        const createView = snapshot(a).views.find(view => view.type === 'WorkspaceCreate' && view.name === 'Workspace: ' + root).id;
        await invoke(a, 'create_file_if_absent', { relativePath: 'slice.ts', content: 'export const slice = 1;' }, { view: createView });
        assert.equal(await fs.readFile(path.join(root, 'slice.ts'), 'utf8'), 'export const slice = 1;');
    });
    await runCase('observed writes, ordered batch, rename identity, stale same-content inode and deletes', async () => {
        await invoke(a, 'write_file', { content: 'export const sibling = 8;\n' }, { view: fileView(a, second).id });
        await invoke(a, 'batch_edit', { edits: [{ filePath: second, oldString: '8', newString: '9' }, { filePath: second, oldString: '9', newString: '10' }] });
        assert.match(await fs.readFile(second, 'utf8'), /10/);
        // A two-item batch can publish its first commit before the final one.
        // Wait for the actual final content before starting the next edit.
        await eventually(() => viewText(a, fileView(a, second).id).includes('export const sibling = 10;'), 'complete batch snapshot');
        const created = path.join(root, 'new/deep/file.ts');
        await invoke(a, 'create_file', { filePath: created, content: 'export const created = true;\n' });
        const renamed = path.join(root, 'move/nested/file.ts'), beforeView = fileView(a, created);
        await invoke(a, 'rename_file', { newPath: renamed }, { view: beforeView.id });
        assert.equal(fileView(a, renamed).id, beforeView.id); assert.equal(fileView(a, renamed).viewInstanceId, beforeView.viewInstanceId);
        const renamedView = fileView(a, renamed), content = await fs.readFile(renamed), stale = scope(a);
        const observed = await stale.observe({ viewIds: [renamedView.id] });
        assert.equal(observed.status, 'observed', JSON.stringify(observed));
        const observation = observed.observation;
        assert.ok(observation.bindings.some(binding => binding.target.viewId === renamedView.id && binding.target.viewInstanceId === renamedView.viewInstanceId));
        const replacement = renamed + '.replacement'; await fs.writeFile(replacement, content); await fs.rename(replacement, renamed);
        try { await invoke(a, 'write_file', { content: 'bad' }, { view: renamedView.id, status: 'failed', changes: false, client: stale, observation }); }
        finally { stale.close(); }
        assert.deepEqual(await fs.readFile(renamed), content);
        await invoke(a, 'multi_open_file', { filePaths: [renamed] }, { changes: false });
        await invoke(a, 'delete_file', {}, { view: fileView(a, renamed).id });
        await assert.rejects(fs.stat(renamed), { code: 'ENOENT' });
        const absent = path.join(root, 'create/file.ts'); await invoke(a, 'create_file', { filePath: absent, content: 'absent only' });
        assert.equal(await fs.readFile(absent, 'utf8'), 'absent only');
        await invoke(a, 'close_file_detail', { view_id: fileView(a, absent).id }, { view: fileView(a, absent).id });
        await invoke(a, 'multi_close_file', { filePaths: [second, second] });
    });
    await runCase('shutdown, actual resource release, physical Worker reuse and managed restoration', async () => {
        const data = a.data, oldViews = snapshot(a).views.map(view => view.viewInstanceId);
        const worker = await close(a, true); await close(b);
        const restarted = await start(root, 'restored', { worker, data, sessionKey: 'a', historyPath: path.join(working, 'history/a.json') });
        assert.ok(fileView(restarted, file)); assert.ok(!fileView(restarted, second));
        assert.ok(snapshot(restarted).views.every(view => !oldViews.includes(view.viewInstanceId)));
        await close(restarted);
    });
    await runCase('explicit legacy rollback entry is separate and uses only a temporary database', async () => {
        const legacy = await start(root, 'legacy', { route: 'legacy' });
        assert.equal(legacy.host.getResourceReport().appCleanup.support, 'legacy-unverified');
        assert.ok(!toolNames(legacy).includes('create_file_if_absent')); await close(legacy);
    });
    facts.passed = true;
} catch (error) {
    facts.failure = { message: String(error), stack: error.stack };
    console.error(error); process.exitCode = 1;
} finally {
    for (const app of apps) if (!app.closed) {
        try { await app.host.close(); } catch (error) { facts.cleanup.push({ id: app.id, failedCleanup: String(error), report: app.host.getResourceReport() }); }
        app.host.terminate(); await app.host.waitForResourceRelease();
    }
    facts.resourceLogs = apps.map(app => ({ id: app.id, logs: app.logs }));
    facts.finishedAt = new Date().toISOString(); facts.working = working;
    if (factsFile) { await fs.mkdir(path.dirname(factsFile), { recursive: true }); await fs.writeFile(factsFile, JSON.stringify(facts, null, 2)); }
    console.log('IDE_FACTS', JSON.stringify({ passed: facts.passed, cases: facts.cases.length, calls: facts.calls.length, factsFile, working }));
}
