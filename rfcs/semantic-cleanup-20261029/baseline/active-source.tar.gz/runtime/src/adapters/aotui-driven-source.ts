/**
 * @aotui/runtime - AOTUIDrivenSource
 * 
 * AOTUI Runtime 到 AgentDriver V2 的适配器
 * 
 * 职责:
 * - 适配 IDesktop 和 IKernel 到 IDrivenSource 接口
 * - 获取 TUI App 状态 (getMessages)
 * - 获取 Operations (getTools)
 * - 执行 Operations (executeTool)
 * - 监听各类信号 (onUpdate)
 */

import type { IDrivenSource, MessageWithTimestamp, ToolResult } from '@aotui/agent-driver-v2';
import { jsonSchema } from 'ai';
import type { IDesktop, IKernel, Operation, OperationID, CachedSnapshot } from '../spi/index.js';

// ============================================================================
// Local Interfaces (解决 SPI 类型缺失问题)
// ============================================================================

/** Operation 参数定义 */
interface OperationParamDef {
    name: string;
    type: 'string' | 'number' | 'boolean' | 'object' | 'array' | 'enum' | 'reference';
    description?: string;
    required?: boolean;
    // array 类型需要 itemType
    itemType?: 'string' | 'number' | 'boolean' | 'object';
    // enum 类型需要 options
    options?: readonly string[];
    // reference 类型需要 refType
    refType?: string;
}

/** IndexMap 中的 Operation 条目结构 */
interface IndexMapOperationEntry {
    type: 'operation';
    appId: string;
    operation: {
        id: string;
        displayName?: string;
        params: OperationParamDef[];
    };
}

interface IndexMapTypeToolEntry {
    description: string;
    params: OperationParamDef[];
    appId?: string;
    appName?: string;
    viewType?: string;
    toolName?: string;
}

interface ResolvedToolContext {
    appId: string;
    viewId?: string;
    operationName: string;
    snapshotId: string;
}

// ============================================================================
// AOTUI System Instruction（Runtime 默认内置，可通过 options/env/path 覆盖）
// ============================================================================

import { readFileSync } from 'fs';
import { DEFAULT_AOTUI_SYSTEM_INSTRUCTION } from './system-instruction.js';

const AOTUI_SYSTEM_INSTRUCTION_PATH_ENV = 'AOTUI_SYSTEM_INSTRUCTION_PATH';
type LayeredMessageWithTimestamp = MessageWithTimestamp & {
    region?: 'static' | 'session' | 'dynamic';
};

/**
 * 懒加载 AOTUI System Instruction
 */
function loadSystemInstruction(instructionPath?: string): string {
    if (!instructionPath) {
        return DEFAULT_AOTUI_SYSTEM_INSTRUCTION;
    }

    try {
        return readFileSync(instructionPath, 'utf-8');
    } catch (error) {
        console.error(
            `[AOTUIDrivenSource] Failed to load system instruction from path: ${instructionPath}`,
            error
        );
        return DEFAULT_AOTUI_SYSTEM_INSTRUCTION;
    }
}

// ============================================================================
// Implementation
// ============================================================================

/**
 * AOTUIDrivenSource 配置
 */
export interface AOTUIDrivenSourceOptions {
    /**
     * 是否注入 AOTUI System Instruction
     * 默认: true
     */
    includeInstruction?: boolean;

    /**
     * 直接覆盖 system instruction 内容
     * 优先级最高
     */
    instruction?: string;

    /**
     * 从指定路径加载 system instruction
     * 优先级低于 instruction，高于环境变量
     */
    instructionPath?: string;
}

/**
 * AOTUI Driven Source (Enhanced)
 * 
 * 将 AOTUI Runtime 暴露给 AgentDriver V2
 * 
 * 设计改进 (RFC: Topic-Desktop Sync):
 * - 注入 AOTUI System Instruction (timestamp=1)
    * - Desktop State timestamp 取最新 app fragment 的时间戳
 * - 优化 Tool 提取逻辑
 */
export class AOTUIDrivenSource implements IDrivenSource {
    readonly name = 'AOTUI';
    
    private includeInstruction: boolean;
    private systemInstruction: string;
    private sourceEnabled = true;
    private disabledApps = new Set<string>();
    private listeners = new Set<() => void>();

    private escapeAttr(value: string): string {
        return value
            .replace(/&/g, '&amp;')
            .replace(/"/g, '&quot;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    }

    private buildViewMessageMarkup(view: {
        appId?: string;
        appName?: string;
        viewId?: string;
        viewType?: string;
        viewName?: string;
        markup: string;
    }): string {
        const viewId = view.viewId || 'unknown';
        const viewType = view.viewType || 'Unknown';
        const viewName = view.viewName || view.viewType || view.viewId || 'Unknown';
        const appId = view.appId || 'unknown';
        const appName = view.appName || 'unknown';

        const attrs = `id="${this.escapeAttr(viewId)}" type="${this.escapeAttr(viewType)}" name="${this.escapeAttr(viewName)}" app_id="${this.escapeAttr(appId)}" app_name="${this.escapeAttr(appName)}"`;
        const rawMarkup = String(view.markup || '').trim();

        if (/^<view\b/i.test(rawMarkup)) {
            const normalizedOpen = `<view ${attrs}>`;
            return rawMarkup.replace(/^<view\b[^>]*>/i, normalizedOpen);
        }

        return `<view ${attrs}>\n${rawMarkup}\n</view>`;
    }

    constructor(
        private desktop: IDesktop,
        private kernel: IKernel,
        options?: AOTUIDrivenSourceOptions
    ) {
        this.includeInstruction = options?.includeInstruction ?? true;

        const instructionFromOptions = options?.instruction?.trim();
        const instructionFromPath = options?.instructionPath;
        const instructionFromEnv = process.env[AOTUI_SYSTEM_INSTRUCTION_PATH_ENV];

        this.systemInstruction = instructionFromOptions && instructionFromOptions.length > 0
            ? instructionFromOptions
            : loadSystemInstruction(instructionFromPath ?? instructionFromEnv);
    }

    setEnabled(enabled: boolean): void {
        this.sourceEnabled = enabled;
        this.triggerUpdate();
    }

    setAppEnabled(appName: string, enabled: boolean): void {
        const normalized = this.normalizeAppKey(appName);
        if (!normalized) {
            return;
        }

        if (enabled) {
            this.disabledApps.delete(normalized);
        } else {
            this.disabledApps.add(normalized);
        }

        this.triggerUpdate();
    }

    private triggerUpdate(): void {
        for (const listener of this.listeners) {
            listener();
        }
    }

    private normalizeAppKey(value: unknown): string {
        if (typeof value !== 'string') {
            return '';
        }
        return value.trim();
    }

    private resolveAppName(appId?: string): string | undefined {
        if (!appId) {
            return undefined;
        }

        try {
            const info = (this.desktop as any).getAppInfo?.(appId);
            if (info && typeof info.name === 'string') {
                return info.name;
            }
        } catch {
        }

        return undefined;
    }

    private isAppAllowed(appId?: string, appName?: string): boolean {
        if (!this.sourceEnabled) {
            return false;
        }

        if (this.disabledApps.size === 0) {
            return true;
        }

        const normalizedId = this.normalizeAppKey(appId);
        const normalizedName = this.normalizeAppKey(appName);

        if (normalizedId && this.disabledApps.has(normalizedId)) {
            return false;
        }

        if (normalizedName && this.disabledApps.has(normalizedName)) {
            return false;
        }

        return true;
    }

    /**
     * 获取消息 (AOTUI System Instruction + TUI App Snapshots)
     * 
     * 使用 Pull-Lease 机制获取最新快照
     * 
     * 消息顺序:
     * 1. AOTUI System Instruction (timestamp=1, role='system')
    * 2. Desktop State (timestamp=latest app fragment, role='user')
     */
    async getMessages(): Promise<MessageWithTimestamp[]> {
        if (!this.sourceEnabled) {
            return [];
        }

        const messages: LayeredMessageWithTimestamp[] = [];
        
        // 1. 注入 AOTUI System Instruction (仅一次)
        if (this.includeInstruction) {
            messages.push({
                role: 'user',
                content: this.systemInstruction,
                timestamp: 1, // ✅ 在 SystemPrompt (0) 之后，在用户消息之前
                region: 'static',
            } as LayeredMessageWithTimestamp);
        }
        
        // 2. 获取 Desktop 的 Snapshot (Pull-Lease)
        const snapshot = await this.kernel.acquireSnapshot(this.desktop.id);

        try {
            const baseTimestamp = snapshot.createdAt || Date.now();

            const desktopTimestamp = snapshot.structured?.desktopTimestamp ?? 2;

            // 3. 优先使用结构化 Snapshot (RFC-014)
            if (snapshot.structured?.appStates) {
                const applicationInstructions = Array.isArray(snapshot.structured.applicationInstructions)
                    ? snapshot.structured.applicationInstructions
                    : [];

                for (const instruction of applicationInstructions) {
                    const instructionAppId = this.normalizeAppKey((instruction as any).appId);
                    const instructionAppName = this.normalizeAppKey((instruction as any).appName)
                        || this.normalizeAppKey(this.resolveAppName(instructionAppId));

                    if (!this.isAppAllowed(instructionAppId, instructionAppName)) {
                        continue;
                    }

                    messages.push({
                        role: 'user',
                        content: instruction.markup,
                        timestamp: instruction.timestamp ?? baseTimestamp,
                        region: 'static',
                    } as LayeredMessageWithTimestamp);
                }

                if (snapshot.structured.desktopState && this.disabledApps.size === 0) {
                    messages.push({
                        role: 'user',
                        content: snapshot.structured.desktopState,
                        timestamp: desktopTimestamp,
                        region: 'dynamic',
                    } as LayeredMessageWithTimestamp);
                }

                const hasViewStates = Array.isArray(snapshot.structured.viewStates)
                    && snapshot.structured.viewStates.length > 0;

                if (hasViewStates) {
                    for (const view of snapshot.structured.viewStates!) {
                        const viewAppId = this.normalizeAppKey((view as any).appId);
                        const viewAppName = this.normalizeAppKey((view as any).appName)
                            || this.normalizeAppKey(this.resolveAppName(viewAppId));

                        if (!this.isAppAllowed(viewAppId, viewAppName)) {
                            continue;
                        }

                        const wrappedView = this.buildViewMessageMarkup({
                            appId: view.appId || viewAppId || 'unknown',
                            appName: view.appName || viewAppName || viewAppId || 'unknown',
                            viewId: view.viewId,
                            viewType: view.viewType,
                            viewName: (view as any).viewName,
                            markup: view.markup,
                        });

                        messages.push({
                            role: 'user',
                            content: wrappedView,
                            timestamp: view.timestamp ?? baseTimestamp,
                            region: 'dynamic',
                        } as LayeredMessageWithTimestamp);
                    }

                    return messages;
                }

                for (const fragment of snapshot.structured.appStates) {
                    const fragmentAppId = this.normalizeAppKey((fragment as any).appId);
                    const fragmentAppName = this.normalizeAppKey((fragment as any).appName)
                        || this.normalizeAppKey(this.resolveAppName(fragmentAppId));

                    if (!this.isAppAllowed(fragmentAppId, fragmentAppName)) {
                        continue;
                    }

                    messages.push({
                        role: 'user',
                        content: `${fragment.markup}`,
                        timestamp: fragment.timestamp ?? baseTimestamp,
                        region: 'dynamic',
                    } as LayeredMessageWithTimestamp);
                }
            }
            // 4. 回退到旧的 markup 解析 (如果需要)
            else if (snapshot.markup && this.disabledApps.size === 0) {
                messages.push({
                    role: 'user',
                    content: `# TUI Desktop State\n\n${snapshot.markup}`,
                    timestamp: baseTimestamp,
                    region: 'dynamic',
                } as LayeredMessageWithTimestamp);
            }

            return messages;
        } finally {
            // 5. 释放 Snapshot (Pull-Lease)
            this.kernel.releaseSnapshot(snapshot.id);
        }
    }

    /**
     * 获取工具 (Operations)
     *
     * 从 IndexMap 提取所有 operations
     *
    * 重要: AI SDK v6 使用 inputSchema 字段而不是 parameters。
    * 如果传入 parameters，inputSchema 为 undefined，会被推断成空 schema。
     */
    async getTools(): Promise<Record<string, any>> {
        if (!this.sourceEnabled) {
            return {};
        }

        const snapshot = await this.kernel.acquireSnapshot(this.desktop.id);

        try {
            const tools: Record<string, any> = {};

            if (snapshot.indexMap) {
                for (const [key, value] of Object.entries(snapshot.indexMap)) {
                    // 1. 传统 Operation Entry (type === 'operation')
                    if (this.isOperationEntry(value)) {
                        if (!this.isAppAllowed(value.appId, this.resolveAppName(value.appId))) {
                            continue;
                        }

                        const op = value.operation;
                        const schema = this.convertParamsToJsonSchema(op.params);
                        tools[op.id] = {
                            description: op.displayName || op.id,
                            inputSchema: jsonSchema(schema),
                        };
                    }
                    // 2. useViewTypeTool 注册的工具 (key 以 'tool:' 开头)
                    else if (key.startsWith('tool:') && this.isTypeToolEntry(value)) {
                        if (!this.isAppAllowed(value.appId, value.appName || this.resolveAppName(value.appId))) {
                            continue;
                        }

                        const toolId = key.slice(5);
                        const params = (value as any).params || [];
                        const schema = this.convertParamsToJsonSchema(params);

                        tools[toolId] = {
                            description: (value as any).description || toolId,
                            inputSchema: jsonSchema(schema),
                        };
                    }
                }
            }

            const systemTools = this.kernel.getSystemToolDefinitions?.() || [];
            for (const tool of systemTools) {
                const fn = (tool as any).function;
                const toolName = fn?.name;
                if (!toolName || tools[toolName]) {
                    continue;
                }

                const schema = fn?.parameters || { type: 'object', properties: {}, required: [] };
                tools[toolName] = {
                    description: fn?.description || toolName,
                    inputSchema: jsonSchema(schema),
                };
            }

            return tools;
        } finally {
            this.kernel.releaseSnapshot(snapshot.id);
        }
    }

    /**
     * 执行工具 (Operation)
     * 
     * 使用 Kernel.execute() 执行 Operation
     */
    async executeTool(
        toolName: string,
        args: unknown,
        toolCallId: string
    ): Promise<ToolResult | undefined> {
        if (!this.sourceEnabled) {
            return {
                toolCallId,
                toolName,
                error: {
                    code: 'E_SOURCE_DISABLED',
                    message: 'AOTUI source is disabled for this topic',
                },
            };
        }

        const ownerId = 'agent-driver';
        const snapshot = await this.kernel.acquireSnapshot(this.desktop.id);
        let lockAcquired = false;

        try {
            const resolvedContext = this.resolveToolContext(snapshot, toolName);
            if (!resolvedContext) {
                return {
                    toolCallId,
                    toolName,
                    error: {
                        code: 'E_TOOL_CONTEXT_NOT_FOUND',
                        message: `Tool "${toolName}" is not available in the current desktop snapshot`,
                    },
                };
            }

            const { appId, viewId, operationName, snapshotId } = resolvedContext;

            const operation: Operation = {
                context: {
                    appId: appId as any,
                    viewId: viewId as any,
                    snapshotId: snapshotId as any,
                },
                name: operationName as OperationID,
                args: args as Record<string, unknown>,
            };

            if (appId !== 'system' && !this.isAppAllowed(appId, this.resolveAppName(appId))) {
                return {
                    toolCallId,
                    toolName,
                    error: {
                        code: 'E_APP_DISABLED',
                        message: `App "${this.resolveAppName(appId) || appId}" is disabled for this topic`,
                    },
                };
            }

            this.kernel.acquireLock(this.desktop.id, ownerId);
            lockAcquired = true;
            const result = await this.kernel.execute(this.desktop.id, operation, ownerId);

            // 4. 转换为 ToolResult
            if (result.success) {
                return {
                    toolCallId,
                    toolName,
                    result: result.data || { success: true }
                };
            } else {
                return {
                    toolCallId,
                    toolName,
                    error: {
                        code: result.error?.code || 'E_EXECUTION_FAILED',
                        message: result.error?.message || 'Unknown error'
                    }
                };
            }
        } catch (error) {
            return {
                toolCallId,
                toolName,
                error: {
                    code: 'E_EXCEPTION',
                    message: error instanceof Error ? error.message : String(error)
                }
            };
        } finally {
            this.kernel.releaseSnapshot(snapshot.id);
            if (lockAcquired) {
                this.kernel.releaseLock(this.desktop.id, ownerId);
            }
        }
    }

    private resolveToolContext(snapshot: CachedSnapshot, toolName: string): ResolvedToolContext | null {
        if (toolName.startsWith('system-')) {
            return {
                appId: 'system',
                operationName: toolName.slice('system-'.length),
                snapshotId: snapshot.id,
            };
        }

        const directToolEntry = snapshot.indexMap?.[`tool:${toolName}`];
        if (this.isTypeToolEntry(directToolEntry)) {
            const appId = directToolEntry.appId;
            const viewType = directToolEntry.viewType;
            const resolvedToolName = directToolEntry.toolName;

            if (
                typeof appId === 'string' && appId.length > 0 &&
                typeof viewType === 'string' && viewType.length > 0 &&
                typeof resolvedToolName === 'string' && resolvedToolName.length > 0
            ) {
                return {
                    appId,
                    viewId: viewType,
                    operationName: resolvedToolName,
                    snapshotId: snapshot.id,
                };
            }
        }

        const parsedDirectToolName = this.parseClassicToolName(toolName);
        if (parsedDirectToolName && directToolEntry !== undefined) {
            const directToolContext = this.resolveClassicToolContext(parsedDirectToolName, directToolEntry, snapshot.id);
            if (directToolContext) {
                return directToolContext;
            }
        }

        for (const value of Object.values(snapshot.indexMap || {})) {
            if (!this.isOperationEntry(value) || value.operation.id !== toolName) {
                continue;
            }

            const parsedOperation = this.parseClassicToolName(value.operation.id);
            if (!parsedOperation) {
                continue;
            }

            return {
                appId: value.appId,
                viewId: parsedOperation.viewId,
                operationName: parsedOperation.operationName,
                snapshotId: snapshot.id,
            };
        }

        return null;
    }

    private resolveClassicToolContext(
        parsed: { viewId?: string; operationName: string },
        entry: unknown,
        snapshotId: string
    ): ResolvedToolContext | null {
        if (this.isOperationEntry(entry)) {
            return {
                appId: entry.appId,
                viewId: parsed.viewId,
                operationName: parsed.operationName,
                snapshotId,
            };
        }

        return null;
    }

    private parseClassicToolName(toolName: string): { viewId?: string; operationName: string } | null {
        const dotParts = toolName.split('.');
        if (dotParts.length >= 3) {
            return {
                viewId: dotParts[1],
                operationName: dotParts.slice(2).join('.'),
            };
        }

        if (dotParts.length === 2) {
            return {
                operationName: dotParts[1],
            };
        }

        return null;
    }

    /**
     * 订阅更新
     */
    onUpdate(callback: () => void): () => void {
        const signalListener = () => callback();
        this.listeners.add(callback);

        // [Fix] output is a property, not a method
        const outputStream = this.desktop.output;

        // 订阅
        outputStream.subscribe(signalListener);

        // 返回取消订阅函数
        return () => {
            this.listeners.delete(callback);
            outputStream.unsubscribe(signalListener);
        };
    }

    /**
     * 类型守卫: 判断是否为 Operation Entry
     */
    private isOperationEntry(entry: unknown): entry is IndexMapOperationEntry {
        return (
            typeof entry === 'object' &&
            entry !== null &&
            (entry as any).type === 'operation' &&
            (entry as any).operation &&
            Array.isArray((entry as any).operation.params)
        );
    }

    /**
     * 类型守卫: 判断是否为 useViewTypeTool 注册的工具
     * 格式: { description: string, params: Array<{ name, type, required, description }> }
     */
    private isTypeToolEntry(entry: unknown): entry is IndexMapTypeToolEntry {
        return (
            typeof entry === 'object' &&
            entry !== null &&
            typeof (entry as any).description === 'string' &&
            Array.isArray((entry as any).params)
        );
    }

    /**
     * 将 Operation params 转换为 JSON Schema
     */
    private convertParamsToJsonSchema(params: OperationParamDef[]): Record<string, unknown> {
        const properties: Record<string, Record<string, unknown>> = {};
        const required: string[] = [];

        for (const param of params) {
            let schema: Record<string, unknown>;

            switch (param.type) {
                case 'string':
                    schema = { type: 'string' };
                    break;
                case 'number':
                    schema = { type: 'number' };
                    break;
                case 'boolean':
                    schema = { type: 'boolean' };
                    break;
                case 'object':
                    schema = { type: 'object' };
                    break;
                case 'array': {
                    const itemType = param.itemType || 'string';
                    let items: Record<string, unknown>;
                    switch (itemType) {
                        case 'string':
                            items = { type: 'string' };
                            break;
                        case 'number':
                            items = { type: 'number' };
                            break;
                        case 'boolean':
                            items = { type: 'boolean' };
                            break;
                        case 'object':
                            items = { type: 'object' };
                            break;
                        default:
                            items = {};
                    }
                    schema = { type: 'array', items };
                    break;
                }
                case 'enum':
                    if (param.options && param.options.length > 0) {
                        schema = { type: 'string', enum: param.options };
                    } else {
                        schema = { type: 'string' };
                    }
                    break;
                case 'reference':
                    schema = { type: 'string' };
                    break;
                default:
                    console.warn(`[AOTUI] Unknown param type: "${param.type}", defaulting to string`);
                    schema = { type: 'string' };
            }

            if (param.description) {
                schema.description = param.description;
            }

            if (param.required) {
                required.push(param.name);
            }

            properties[param.name] = schema;
        }

        return {
            type: 'object',
            properties,
            ...(required.length > 0 ? { required } : {}),
        };
    }
}
