/**
 * M5: source-bound Invocation over a Runtime-committed V2 AppSnapshot.
 *
 * INTERNAL convergence slice, not a public Runtime export. No DOM, Worker,
 * Host, model SDK or business filesystem dependencies. The current binding
 * is (snapshotId, toolId, viewId, optional refId), not yet a separate
 * caller-facing Observation / ActionBinding document.
 *
 * The adapter is TRUSTED: it validates the observed schema, verifies live
 * View ownership and performs the actual business authorization/version CAS.
 * A preflight read cannot make a remote read-modify-write atomic.
 */
import { canonicalJson, copyJson } from '../snapshot/json.js';
import type { JsonValue, SnapshotStore, ToolDescriptorV2, ToolTargetV2 } from '../snapshot/types.js';
import {
    acquireToolSource, acquireVersionedEntitySource,
    type ToolSourceRequest, type ToolSourceSelection, type VersionedEntitySourceSelection,
} from '../tool/source-binding.js';

import { createInvocationLedger } from './invocation-ledger.js';
import { parseActionOutcome, type ActionOutcome } from './invocation-outcome.js';
export type { ActionOutcome } from './invocation-outcome.js';

export interface BoundInvocation extends ToolSourceRequest {
    readonly invocationId: string;
    /** Required by mutating Tools: an entity Ref published by the source V2 snapshot. */
    readonly refId?: string;
    readonly input: unknown;
}

export interface BoundActionSource {
    readonly snapshotId: string;
    readonly appId: string;
    readonly instanceId: string;
    readonly tool: ToolDescriptorV2;
    readonly target: ToolTargetV2;
    /** Derived from the ORIGINAL observed Ref, never caller-controlled input. */
    readonly resource?: Readonly<{
        entityType: string;
        entityId: string;
        entityVersion: string;
    }>;
}

export type InputValidation =
    | Readonly<{ ok: true; value: JsonValue }>
    | Readonly<{ ok: false; message: string }>;

export type LiveBindingCheck =
    | Readonly<{ ok: true }>
    | Readonly<{ ok: false; code: string; message: string }>;

export interface BoundActionContext {
    readonly source: BoundActionSource;
    /** Pass unchanged to business adapters for durable idempotency and audit. */
    readonly invocationId: string;
    readonly signal: AbortSignal;
}

export interface BoundActionAdapter {
    /** Must validate input against source.tool.inputSchema. */
    validateInput(source: BoundActionSource, input: JsonValue): InputValidation | Promise<InputValidation>;
    /** Authorizes this actor/scope/operation; not implied by a valid Snapshot. */
    authorize(source: BoundActionSource, input: JsonValue): boolean | Promise<boolean>;
    /** Synchronous live View/Tool owner verification, including uncommitted unmounts. */
    isLive(source: BoundActionSource): LiveBindingCheck;
    /** The business adapter MUST atomically compare the observed resource version. */
    execute(context: BoundActionContext, input: JsonValue): ActionOutcome | Promise<ActionOutcome>;
}

export interface BoundActionExecutor {
    invoke(invocation: BoundInvocation): Promise<ActionOutcome>;
    /** Signal in-flight adapters, retain receipts, reject new calls. No rollback claim. */
    close(): void;
    inspect(): Readonly<{ closed: boolean; active: number; receipts: number }>;
}

const LIMITS = Object.freeze({ maxDepth: 32, maxNodes: 5_000, maxApproxBytes: 128 * 1024 });
const rejected = (code: string, message: string): ActionOutcome =>
    Object.freeze({ status: 'rejected' as const, code, message });
const failed = (code: string, message: string): ActionOutcome =>
    Object.freeze({ status: 'failed' as const, code, message, effects: 'none' as const });
const unknown = (code: string, message: string): ActionOutcome =>
    Object.freeze({ status: 'unknown' as const, code, message });

function record(value: JsonValue): value is Readonly<Record<string, JsonValue>> {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
}
function nonEmpty(value: unknown): value is string {
    return typeof value === 'string' && value.trim().length > 0;
}

/** Copy before any await. User JavaScript objects are not retained or frozen in place. */
function capture(input: unknown): {
    invocation: Readonly<BoundInvocation & { input: JsonValue }>;
    fingerprint: string;
} {
    const value = copyJson(input, LIMITS);
    if (!record(value)) throw new TypeError('Expected an Invocation object');
    const mandatory = ['appId', 'instanceId', 'snapshotId', 'toolId', 'viewId', 'invocationId', 'input'];
    if (mandatory.some(field => !Object.hasOwn(value, field)) ||
        Object.keys(value).some(field => ![...mandatory, 'refId'].includes(field)) ||
        mandatory.slice(0, -1).some(field => !nonEmpty(value[field])) ||
        (Object.hasOwn(value, 'refId') && !nonEmpty(value.refId)) ||
        !record(value.input)) {
        throw new TypeError('Invalid Invocation fields or non-object Tool input');
    }
    return {
        invocation: value as unknown as Readonly<BoundInvocation & { input: JsonValue }>,
        fingerprint: canonicalJson(value),
    };
}

/** Never let a handler's success-ish object bypass the five-state contract. */
function normalizeOutcome(raw: unknown): ActionOutcome {
    return parseActionOutcome(copyJson(raw, LIMITS));
}

/**
 * Memory-only, bounded receipt ledger. The caller owns this instance's scope.
 * Saturation rejects new IDs, never drops old entries and replays a side effect.
 * No cross-process or crash-safe exactly-once guarantee is made.
 */
export function createBoundActionExecutor(
    store: SnapshotStore,
    adapter: BoundActionAdapter,
    options: { readonly maxReceipts?: number } = {},
): BoundActionExecutor {
    const maxReceipts = options.maxReceipts ?? 1_024;
    if (!Number.isSafeInteger(maxReceipts) || maxReceipts <= 0) {
        throw new RangeError('maxReceipts must be a positive safe integer');
    }
    const receipts = createInvocationLedger<Promise<ActionOutcome>>(maxReceipts);
    const active = new Set<AbortController>();
    let closed = false;

    function acquire(request: Readonly<BoundInvocation>):
        ToolSourceSelection | VersionedEntitySourceSelection {
        const selector: ToolSourceRequest = {
            appId: request.appId, instanceId: request.instanceId,
            snapshotId: request.snapshotId, toolId: request.toolId, viewId: request.viewId,
        };
        const tool = acquireToolSource(store, selector);
        if (tool.status === 'rejected') return tool;
        if (!tool.tool.isMutating) {
            if (request.refId === undefined) return tool;
            tool.release();
            return { status: 'rejected' as const, issue: {
                code: 'REF_CONTRACT_UNSUPPORTED' as const,
                message: 'Ref arguments for read-only Tools are outside this slice',
            } };
        }
        tool.release();
        if (!request.refId) return { status: 'rejected' as const, issue: {
            code: 'RESOURCE_VERSION_REQUIRED' as const,
            message: 'Mutation requires a source-bound versioned Entity Ref',
        } };
        return acquireVersionedEntitySource(store, { ...selector, refId: request.refId });
    }

    async function run(
        request: Readonly<BoundInvocation & { input: JsonValue }>,
        controller: AbortController,
    ): Promise<ActionOutcome> {
        if (closed || controller.signal.aborted) {
            return rejected('INVOCATION_CLOSED', 'Executor closed before execution started');
        }
        const selected = acquire(request);
        if (selected.status === 'rejected') return rejected(selected.issue.code, selected.issue.message);
        try {
            const source: BoundActionSource = Object.freeze({
                snapshotId: selected.snapshotId, appId: request.appId, instanceId: request.instanceId,
                tool: selected.tool, target: selected.target,
                ...('resource' in selected ? { resource: selected.resource } : {}),
            });

            // Re-select exactly the ORIGINAL source after each async boundary.
            const recheck = (): ActionOutcome | undefined => {
                if (closed || controller.signal.aborted) {
                    return rejected('INVOCATION_CLOSED', 'Execution stopped during preflight');
                }
                const current = acquire(request);
                if (current.status === 'rejected') return rejected(current.issue.code, current.issue.message);
                current.release();
                try {
                    const live = adapter.isLive(source);
                    if (live?.ok === false && nonEmpty(live.code) && nonEmpty(live.message)) {
                        return rejected(live.code, live.message);
                    }
                    if (live?.ok !== true) {
                        return failed('LIVE_BINDING_CHECK_FAILED', 'Live owner validator returned an invalid status');
                    }
                } catch {
                    return failed('LIVE_BINDING_CHECK_FAILED', 'Live owner validation failed');
                }
                return undefined;
            };

            let validation: InputValidation;
            try {
                validation = await adapter.validateInput(source, request.input);
            } catch {
                return failed('INPUT_VALIDATOR_FAILED', 'Input validation failed unexpectedly');
            }
            if (!validation || typeof validation !== 'object' || typeof validation.ok !== 'boolean') {
                return failed('INPUT_VALIDATOR_FAILED', 'Input validator returned an invalid response');
            }
            if (!validation.ok) return rejected('ACTION_INPUT_INVALID', validation.message || 'Invalid action input');
            let input: JsonValue;
            try {
                input = copyJson(validation.value, LIMITS);
            } catch {
                return rejected('ACTION_INPUT_INVALID', 'Validated input is not bounded JSON data');
            }
            if (!record(input)) return rejected('ACTION_INPUT_INVALID', 'Validated input must be an object');
            const afterValidation = recheck();
            if (afterValidation) return afterValidation;

            let authorized: boolean;
            try {
                authorized = await adapter.authorize(source, input);
            } catch {
                return failed('AUTHORIZATION_FAILED', 'Authorization policy failed unexpectedly');
            }
            if (authorized !== true) return rejected('TOOL_PERMISSION_DENIED', 'Action was not authorized');
            const beforeExecution = recheck();
            if (beforeExecution) return beforeExecution;

            // After entering the business adapter, exceptions cannot prove no side effect.
            const context: BoundActionContext = Object.freeze({
                source, invocationId: request.invocationId, signal: controller.signal,
            });
            try {
                return normalizeOutcome(await adapter.execute(context, input));
            } catch {
                return unknown('ACTION_OUTCOME_UNKNOWN',
                    'Execution began but its final business outcome could not be established');
            }
        } finally {
            selected.release();
        }
    }

    return Object.freeze({
        invoke(raw: BoundInvocation): Promise<ActionOutcome> {
            let captured: ReturnType<typeof capture>;
            try {
                captured = capture(raw);
            } catch {
                return Promise.resolve(rejected('INVOCATION_INVALID',
                    'Expected bounded plain JSON with source IDs and an object input'));
            }
            const { invocation, fingerprint } = captured;
            const existing = receipts.lookup(invocation.invocationId, fingerprint);
            if (existing.status === 'match') return existing.value;
            if (existing.status === 'conflict') return Promise.resolve(rejected('INVOCATION_ID_CONFLICT', 'Invocation ID reused with different request'));
            if (closed) return Promise.resolve(rejected('INVOCATION_CLOSED', 'Executor is closed'));
            if (receipts.size >= maxReceipts) {
                return Promise.resolve(rejected('INVOCATION_CAPACITY',
                    'Receipt capacity exhausted; existing entries will not be evicted'));
            }
            const controller = new AbortController();
            active.add(controller);
            // Reserve synchronously BEFORE any adapter code can run.
            const result = Promise.resolve()
                .then(() => run(invocation, controller))
                .catch(() => unknown('ACTION_OUTCOME_UNKNOWN', 'Unexpected invocation failure'))
                .finally(() => { active.delete(controller); });
            receipts.claim(invocation.invocationId, fingerprint, result);
            return result;
        },
        close(): void {
            if (closed) return;
            closed = true;
            for (const controller of active) controller.abort();
        },
        inspect() {
            return Object.freeze({ closed, active: active.size, receipts: receipts.size });
        },
    });
}
