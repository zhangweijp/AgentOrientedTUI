import { describe, expect, it, vi } from 'vitest';
import { createSnapshotCore, refKey } from '../snapshot/index.js';
import type { PreparedAppSnapshotDraftV2 } from '../snapshot/types.js';
import { createViewOwnedTools } from '../tool/view-owned-tools.js';
import {
    createBoundActionExecutor,
    type ActionOutcome, type BoundActionAdapter, type BoundInvocation, type InputValidation,
} from './bound-action-executor.js';

const appId = 'tasks';
const instanceId = 'tasks-run-1';
const completeId = JSON.stringify([appId, 'Task', 'complete']);
const inspectId = JSON.stringify([appId, 'Task', 'inspect']);

function deferred<T>() {
    let resolve!: (value: T) => void;
    const promise = new Promise<T>(done => { resolve = done; });
    return { promise, resolve };
}

function fixture() {
    const core = createSnapshotCore();
    core.lifecycle.startApp(appId, instanceId);
    const owner = createViewOwnedTools(appId, instanceId);
    let current = owner.mount('tasks_view', 'Task');
    let seq = 0;
    let version = '1';
    let done = false;
    let executions = 0;
    const schema = { type: 'object', properties: {}, additionalProperties: false };
    const register = (viewInstanceId: string) => {
        owner.registerTool(viewInstanceId, {
            name: 'complete', description: 'Complete the observed Task', inputSchema: schema,
            isMutating: true,
        }, async () => ({ success: true }));
        owner.registerTool(viewInstanceId, {
            name: 'inspect', description: 'Inspect Task', inputSchema: schema,
            isMutating: false,
        }, async () => ({ success: true }));
    };
    register(current.viewInstanceId);

    const publish = (content = 'Task snapshot') => {
        seq++;
        const live = owner.listViews();
        const draft: PreparedAppSnapshotDraftV2 = {
            schemaVersion: 2, appId, instanceId, producerSeq: seq, sourceEpoch: seq,
            capturedAt: seq,
            views: live.map(view => ({
                id: view.viewId, viewInstanceId: view.viewInstanceId, type: 'Task',
                name: view.viewId, kind: 'state',
                content: { format: 'semantic-v1', value: { label: content, done, version } },
            })),
            refs: Object.fromEntries(live.map(view => [
                refKey(view.viewId, view.viewInstanceId, 'task'),
                {
                    id: 'task', ownerViewId: view.viewId, ownerViewInstanceId: view.viewInstanceId,
                    refType: 'Task', target: {
                        kind: 'entity' as const, entityType: 'Task', entityId: view.viewId,
                        entityVersion: version,
                    },
                },
            ])),
            tools: Object.fromEntries(owner.listTools().map(tool => [
                tool.id, {
                    id: tool.id, name: tool.name, viewType: tool.viewType,
                    description: tool.description, inputSchema: tool.inputSchema,
                    isMutating: tool.isMutating, targets: tool.targets,
                },
            ])),
        };
        const result = core.committer.accept(draft);
        if (result.status === 'rejected') throw new Error(JSON.stringify(result.issue));
        return result.snapshot;
    };

    const authorize = vi.fn(async () => true);
    const validateInput = vi.fn(async (_source: unknown, input: unknown): Promise<InputValidation> =>
        input && typeof input === 'object' && !Array.isArray(input) && Object.keys(input).length === 0
            ? { ok: true, value: {} }
            : { ok: false, message: 'Only an empty object is allowed' });
    const execute = vi.fn(async (context: Parameters<BoundActionAdapter['execute']>[0]): Promise<ActionOutcome> => {
        const source = context.source;
        executions++;
        if (source.tool.id === inspectId) {
            return { status: 'succeeded', value: { version, done } };
        }
        // Demonstrates a business-owned synchronous CAS against the ORIGINAL ref.
        // A database adapter would perform this inside its own transaction.
        if (!source.resource || source.resource.entityVersion !== version) {
            return { status: 'rejected', code: 'RESOURCE_VERSION_STALE', message: 'Task changed externally' };
        }
        done = true;
        version = String(Number(version) + 1);
        return { status: 'succeeded', value: { done, version } };
    });

    const adapter: BoundActionAdapter = {
        validateInput, authorize,
        isLive(source) {
            const result = owner.validate({
                ...source.tool, appId: source.appId, appInstanceId: source.instanceId,
            }, source.target);
            return result.success
                ? { ok: true }
                : {
                    ok: false,
                    code: result.error?.code || 'TOOL_SOURCE_STALE',
                    message: result.error?.message || 'The Tool is no longer available',
                };
        },
        execute,
    };
    const request = (snapshotId: string, invocationId = 'call-1',
                     toolId = completeId, viewId = 'tasks_view'): BoundInvocation => ({
        snapshotId, appId, instanceId, toolId, viewId,
        ...(toolId === completeId ? { refId: 'task' } : {}),
        invocationId, input: {},
    });
    return {
        core, owner, adapter, authorize, validateInput, execute, request, publish,
        get executions() { return executions; },
        get version() { return version; },
        setVersion(value: string) { version = value; },
        mountSibling(viewId: string) {
            const sibling = owner.mount(viewId, 'Task');
            register(sibling.viewInstanceId);
            return sibling;
        },
        unmount() { owner.unmount(current.viewInstanceId); },
        remount() {
            owner.unmount(current.viewInstanceId);
            current = owner.mount('tasks_view', 'Task');
            register(current.viewInstanceId);
            return current;
        },
    };
}

describe('Semantic Core convergence: committed Snapshot V2 → source-bound Invocation', () => {
    it('runs without DOM/Worker/Host and binds an original versioned business entity', async () => {
        const x = fixture();
        const snapshot = x.publish();
        const runner = createBoundActionExecutor(x.core.store, x.adapter);
        const result = await runner.invoke(x.request(snapshot.id));
        expect(result).toEqual({ status: 'succeeded', value: { done: true, version: '2' } });
        expect(x.executions).toBe(1);
        expect(x.core.store.inspect().activeLeases).toBe(0);
        expect(Object.isFrozen(result)).toBe(true);
    });

    it('does not invalidate a read-only action when only displayed content changes', async () => {
        const x = fixture();
        const original = x.publish();
        x.publish('Only the view content changed');
        const runner = createBoundActionExecutor(x.core.store, x.adapter);
        const result = await runner.invoke(x.request(original.id, 'read', inspectId));
        expect(result).toMatchObject({ status: 'succeeded', value: { version: '1', done: false } });
    });

    it('rejects an old binding after the owning View was unmounted, even before a new Snapshot', async () => {
        const x = fixture();
        const original = x.publish();
        x.unmount();
        const result = await createBoundActionExecutor(x.core.store, x.adapter)
            .invoke(x.request(original.id));
        expect(result).toMatchObject({ status: 'rejected', code: 'VIEW_INSTANCE_REVOKED' });
        expect(x.executions).toBe(0);
    });

    it('rejects old instances after close/reopen with same public View ID', async () => {
        const x = fixture();
        const original = x.publish();
        x.remount();
        x.publish('New View instance');
        const result = await createBoundActionExecutor(x.core.store, x.adapter)
            .invoke(x.request(original.id));
        expect(result).toMatchObject({ status: 'rejected', code: 'VIEW_INSTANCE_REVOKED' });
    });

    it('rechecks the original binding after async validation, before authorization', async () => {
        const x = fixture();
        const snapshot = x.publish();
        const entered = deferred<void>();
        const gate = deferred<InputValidation>();
        x.adapter.validateInput = () => { entered.resolve(); return gate.promise; };
        const runner = createBoundActionExecutor(x.core.store, x.adapter);
        const pending = runner.invoke(x.request(snapshot.id));
        await entered.promise;
        x.remount();
        x.publish('Changed during validation');
        gate.resolve({ ok: true, value: {} });
        expect(await pending).toMatchObject({ status: 'rejected', code: 'VIEW_INSTANCE_REVOKED' });
        expect(x.authorize).not.toHaveBeenCalled();
        expect(x.executions).toBe(0);
    });

    it('rechecks after async authorization and denies changed resource versions', async () => {
        const x = fixture();
        const snapshot = x.publish();
        const entered = deferred<void>();
        const gate = deferred<boolean>();
        x.adapter.authorize = () => { entered.resolve(); return gate.promise; };
        const runner = createBoundActionExecutor(x.core.store, x.adapter);
        const pending = runner.invoke(x.request(snapshot.id));
        await entered.promise;
        x.setVersion('2');
        x.publish('New Task revision');
        gate.resolve(true);
        expect(await pending).toMatchObject({ status: 'rejected', code: 'RESOURCE_VERSION_STALE' });
        expect(x.executions).toBe(0);
    });

    it('a business CAS protects against external writes even before projection refresh', async () => {
        const x = fixture();
        const snapshot = x.publish();
        x.setVersion('9'); // out-of-band change not yet included in published Snapshot
        const result = await createBoundActionExecutor(x.core.store, x.adapter)
            .invoke(x.request(snapshot.id));
        expect(result).toMatchObject({ status: 'rejected', code: 'RESOURCE_VERSION_STALE' });
        expect(x.executions).toBe(1); // adapter entered; it rejected without writing
    });

    it('deduplicates concurrent/completed IDs, detects conflicting reuse, and holds receipts', async () => {
        const x = fixture();
        const snapshot = x.publish();
        const entered = deferred<void>();
        const gate = deferred<ActionOutcome>();
        x.adapter.execute = () => { entered.resolve(); return gate.promise; };
        const runner = createBoundActionExecutor(x.core.store, x.adapter, { maxReceipts: 1 });
        const a = runner.invoke(x.request(snapshot.id));
        const b = runner.invoke(x.request(snapshot.id));
        expect(a).toBe(b);
        await entered.promise;
        expect(await runner.invoke({ ...x.request(snapshot.id), input: { changed: true } }))
            .toMatchObject({ status: 'rejected', code: 'INVOCATION_ID_CONFLICT' });
        expect(await runner.invoke(x.request(snapshot.id, 'second')))
            .toMatchObject({ status: 'rejected', code: 'INVOCATION_CAPACITY' });
        gate.resolve({ status: 'succeeded', value: { committed: true } });
        expect(await a).toEqual({ status: 'succeeded', value: { committed: true } });
        expect(await b).toEqual(await runner.invoke(x.request(snapshot.id)));
        expect(runner.inspect()).toEqual({ closed: false, active: 0, receipts: 1 });
    });

    it('resolves two same-type View targets independently using the ORIGINAL ref scope', async () => {
        const x = fixture();
        const sibling = x.mountSibling('task_alt');
        const snapshot = x.publish();
        expect(x.owner.listTools().find(tool => tool.id === completeId)?.targets).toHaveLength(2);
        x.adapter.execute = ({ source, invocationId }) => ({
            status: 'succeeded',
            value: {
                entityId: source.resource?.entityId ?? null,
                viewId: source.target.viewId,
                viewInstanceId: source.target.viewInstanceId,
                invocationId,
            },
        });
        const result = await createBoundActionExecutor(x.core.store, x.adapter)
            .invoke(x.request(snapshot.id, 'sibling-call', completeId, 'task_alt'));
        expect(result).toEqual({
            status: 'succeeded',
            value: {
                entityId: 'task_alt', viewId: 'task_alt',
                viewInstanceId: sibling.viewInstanceId, invocationId: 'sibling-call',
            },
        });
    });

    it('returns the live Tool error if a binding was disabled before publishing a new Snapshot', async () => {
        const x = fixture();
        const snapshot = x.publish();
        const originalOwner = x.owner.listViews()[0]!;
        x.owner.setEnabled(originalOwner.viewInstanceId, 'complete', false);
        const result = await createBoundActionExecutor(x.core.store, x.adapter)
            .invoke(x.request(snapshot.id));
        expect(result).toMatchObject({ status: 'rejected', code: 'TOOL_UNAVAILABLE' });
        expect(x.executions).toBe(0);
    });

    it('copies user input before any asynchronous validator or executor can inspect it', async () => {
        const x = fixture();
        const snapshot = x.publish();
        const input: Record<string, unknown> = {};
        const runner = createBoundActionExecutor(x.core.store, x.adapter);
        const pending = runner.invoke({ ...x.request(snapshot.id), input });
        input.modified = true;
        expect(await pending).toMatchObject({ status: 'succeeded' });
        expect(x.executions).toBe(1);
    });

    it('fails closed on forged refs, unauthorized writes, and invalid validation input', async () => {
        const x = fixture();
        const snapshot = x.publish();
        const runner = createBoundActionExecutor(x.core.store, x.adapter);
        expect(await runner.invoke({ ...x.request(snapshot.id), refId: 'nonexistent' }))
            .toMatchObject({ status: 'rejected', code: 'REF_NOT_FOUND' });
        expect(await runner.invoke({ ...x.request(snapshot.id, 'without-ref'), refId: undefined }))
            .toMatchObject({ status: 'rejected', code: 'INVOCATION_INVALID' });
        x.adapter.authorize = () => false;
        expect(await runner.invoke(x.request(snapshot.id, 'unauthorized')))
            .toMatchObject({ status: 'rejected', code: 'TOOL_PERMISSION_DENIED' });
        expect(await runner.invoke({ ...x.request(snapshot.id, 'bad-input'), input: { extra: 1 } }))
            .toMatchObject({ status: 'rejected', code: 'ACTION_INPUT_INVALID' });
        expect(x.executions).toBe(0);
    });

    it('does not execute getters or trust caller mutation after capture', async () => {
        const x = fixture();
        const snap = x.publish();
        let reads = 0;
        const malicious: Record<string, unknown> = {};
        Object.defineProperty(malicious, 'extra', {
            enumerable: true,
            get() { reads++; return 1; },
        });
        const runner = createBoundActionExecutor(x.core.store, x.adapter);
        expect(await runner.invoke({ ...x.request(snap.id), input: malicious }))
            .toMatchObject({ status: 'rejected', code: 'INVOCATION_INVALID' });
        expect(reads).toBe(0);
        expect(x.executions).toBe(0);
    });

    it('preserves accepted/failed/unknown outcomes; thrown or invalid post-entry results become unknown', async () => {
        const x = fixture();
        const snap = x.publish();
        const runner = createBoundActionExecutor(x.core.store, x.adapter);
        const cases: ActionOutcome[] = [
            { status: 'accepted', operationId: 'job-1' },
            { status: 'failed', code: 'DISK', message: 'Partial write', effects: 'partial' },
            { status: 'unknown', code: 'TIMEOUT', message: 'Inspect the resource' },
        ];
        for (const [i, outcome] of cases.entries()) {
            x.adapter.execute = () => outcome;
            expect(await runner.invoke(x.request(snap.id, 'case-' + i))).toEqual(outcome);
        }
        x.adapter.execute = () => { throw new Error('Write could have committed'); };
        expect(await runner.invoke(x.request(snap.id, 'exception')))
            .toMatchObject({ status: 'unknown', code: 'ACTION_OUTCOME_UNKNOWN' });
        x.adapter.execute = () => ({ success: true } as unknown as ActionOutcome);
        expect(await runner.invoke(x.request(snap.id, 'bad-result')))
            .toMatchObject({ status: 'unknown', code: 'ACTION_OUTCOME_UNKNOWN' });
    });

    it('closing before handler entry rejects; closing during business work only signals cancellation', async () => {
        const x = fixture();
        const snap = x.publish();
        const runner = createBoundActionExecutor(x.core.store, x.adapter);
        runner.close();
        expect(await runner.invoke(x.request(snap.id)))
            .toMatchObject({ status: 'rejected', code: 'INVOCATION_CLOSED' });

        const y = fixture();
        const s = y.publish();
        const next = createBoundActionExecutor(y.core.store, y.adapter);
        const entered = deferred<AbortSignal>();
        const gate = deferred<ActionOutcome>();
        y.adapter.execute = (context) => {
            entered.resolve(context.signal);
            return gate.promise;
        };
        const pending = next.invoke(y.request(s.id));
        const signal = await entered.promise;
        next.close();
        expect(signal.aborted).toBe(true);
        gate.resolve({ status: 'succeeded', value: { persisted: true } });
        expect(await pending).toEqual({ status: 'succeeded', value: { persisted: true } });
        expect(await next.invoke(y.request(s.id))).toEqual({ status: 'succeeded', value: { persisted: true } });
        expect(y.core.store.inspect().activeLeases).toBe(0);
    });
});
