# Ordinary tools and application cleanup

General View-local operations use the existing `useViewTypeTool` and `ordinary-v2` channel. The SDK does not require an entity Ref, business version, or a second result wrapper for a mutation. The W10-only entity Hook, private wrapper, capability and IPC messages have been removed. Core's existing Ref/source-binding and optional M4 file adapter remain available for their existing consumers.

## Execution responsibility

The Host still binds calls to the observed App instance, View incarnation and Tool binding. Scope policy, parameter validation, invocation receipts and duplicate-call handling remain in the existing Core. Worker registration must qualify the actual wrapper; a public Tool description cannot grant execution permission.

A normal handler returns `OperationResult` only after its own work finishes. File identity, business versions, concurrent edits, commit conditions and real business completion are application responsibilities. Framework instance/binding checks do not prove those conditions. A valid old observation can call an unchanged binding against the application's current state; applications that need an expected business version put that requirement in their own parameters or checks.

A failed result can optionally declare `effects: 'none' | 'partial'`. The SDK carries that application declaration through the existing terminal `failureEffects` field and removes it from `terminal.result`. Missing evidence retains Core's existing unknown outcome and original error/data. Throwing, losing a response, aborting a waiter or closing a Scope never proves that a business effect did not happen. No automatic retry is added.

Only five interaction modes remain. `ordinary-v2` now accepts general parameterized tools, including `isMutating: true`; its Host configuration needs `snapshotShadow: true` and the explicit mode. Read-only and Ref modes retain their own contracts. Older Workers may negotiate ordinary-v2 reads but reject a mutating wrapper or request; use the tested matching Runtime/SDK artifacts for general mutations. No downgrade to a legacy call is attempted.

## Application cleanup

`createTUIApp({ experimentalAppLifecycle: true, ... })` opts into the single `app-lifecycle-v2` protocol. `experimental_useAppLifecycle` accepts optional `stop` and `close` callbacks. No registered callbacks is a normal completed close. A single registration is the internal ownership rule; there is no required owner count or callback-count reporting API.

The existing close order stays: revoke calls and stop admission; seal/flush managed persistence; join initialization; unmount; await application close; dispose framework resources. `stop` is synchronous and `close` may be asynchronous. A late registration is stopped immediately. Unmount does not discard registered cleanup work. Preact asynchronous effect cleanup is not made awaitable by this API.

The callback report contains only `protocol`, `instanceId`, `state`, and `issues`. It reports whether callbacks completed, not proof of every resource the application may have opened. `Host.resourcesReleased` is computed from Host-owned Worker, storage, in-flight file operations and Scope facts. Upper reports retain callback failures separately: `ok: false` can coexist with `resourcesReleased: true` after the known framework resources have actually ended.

A failed/incomplete callback does not permit healthy Worker reuse. The Host destroys that executor and keeps the error. The Runtime cannot infer that an external child process ended merely because a callback returned or a Worker exited; an IDE managing LSP children owns that cleanup and its evidence.

The old experimental v1 marker is rejected. Existing unmarked legacy factories retain their existing legacy path. Wrong response type, instance or phase remains a protocol failure. See the SDK [tool/lifecycle guide](../../sdk/docs/tool-lifecycle.md) and IDE `SCOPED_IDE.md` for the application API and migration.
