# Runtime App 的实验交互入口

可信宿主在安装 App 时声明模式，然后在当前运行实例上创建 Scope。安装、Worker、快照和 Scope 使用原来的所有者链。`experimentalCreateAppScope` 是同步创建入口；它不启动 pending App，也不分配第二个 Worker。默认不声明模式时仍沿原路径运行。

本轮将普通参数写操作接入已有 `ordinary-v2`，不要求实体 Ref 或业务版本。App lifecycle 使用可选回调的 v2 offer/ACK。下方五模式例子保留只读与 Ref 的合同；普通写操作及完整 IDE 入口见 [普通 Tool 与应用清理](tool-lifecycle.md)。

下面两段代码分别保存为 `app.mjs` 和 `example.ts`。App 使用 SDK 的公开工具声明；宿主使用 Runtime 的公开安装和 Scope 工厂。这个例子覆盖五种现有协议，不启用旧实验 File Replace，也不切换默认 Agent Router。创建工具只返回业务结果，例子没有文件创建效果。

<!-- b2-app:start -->
```js
import { h } from 'preact';
import { createTUIApp, View, useDataRef, useViewTypeTool,
  experimental_useReadOnlyTool, experimental_useCreateIfAbsentTool } from '@aotui/sdk';

let calls = 0;
function Detail() {
  const file = useDataRef('file', { text: 'original' });
  const result = async args => ({ success: true, data: { args, calls: ++calls } });
  useViewTypeTool('ordinary', { description: 'Read the call count', params: {}, isMutating: false }, result);
  experimental_useReadOnlyTool('parameters', { description: 'Read a text parameter',
    params: { text: { type: 'string', required: true } } }, result);
  const ref = { type: 'reference', required: true, refSource: 'snapshot-value-v1' };
  useViewTypeTool('ref', { description: 'Read the displayed value', params: { file: ref }, isMutating: false }, result);
  experimental_useReadOnlyTool('ref_parameters', { description: 'Read the displayed value with a text parameter',
    params: { file: ref, text: { type: 'string', required: true } } }, result);
  experimental_useCreateIfAbsentTool('create', { description: 'Return a creation outcome without filesystem effects',
    params: { relativePath: { type: 'string', required: true }, content: { type: 'string', required: true } } },
    async args => ({ status: 'succeeded', value: { relativePath: args.relativePath, calls: ++calls } }));
  return h('p', {}, file('Original value'));
}
export default createTUIApp({ app_name: 'interaction_example',
  component: () => h(View, { id: 'detail', type: 'Detail' }, h(Detail, {})) });
```
<!-- b2-app:end -->

Scope 的 project 是宿主制定的可见范围。这里为了演示，授权选中 View 的来源；实际产品应按用户权限收窄。

<!-- b2-example:start -->
```ts
import { createRuntime, type InteractionMode } from '@aotui/runtime';
import type { ScopePolicy, ScopeClient, Observation } from '@aotui/runtime/core';

export async function runExample(appUrl: string, dataDirectory: string) {
  const runtime = createRuntime({ worker: { timeoutMs: 4000, pool: { initialSize: 0, maxSize: 2 } } });
  const desktopId = await runtime.createDesktop();
  const desktop = runtime.getDesktop(desktopId);
  const modes: InteractionMode[] = ['ordinary-v1', 'ordinary-v2', 'snapshot-value-v1', 'snapshot-value-v2', 'create-if-absent-v1'];
  const policy: ScopePolicy = {
    project: ({ source, selection }) => ({
      views: source.views.filter(v => selection.viewIds.includes(v.id)).map(v => ({ viewId: v.id, viewInstanceId: v.viewInstanceId })),
      refs: Object.values(source.refs).filter(r => selection.viewIds.includes(r.ownerViewId)).map(r => ({ viewId: r.ownerViewId, viewInstanceId: r.ownerViewInstanceId, refId: r.id })),
      targets: Object.values(source.tools).flatMap(t => t.targets.filter(target => selection.viewIds.includes(target.viewId)).map(target => ({ toolId: t.id, target }))),
      content: [],
    }),
    authorize: () => true,
    canReadReceipt: () => true,
  };
  async function observeReady(client: ScopeClient): Promise<Observation> {
    const deadline = Date.now() + 6000;
    while (Date.now() < deadline) {
      let notify!: () => void;
      const changed = new Promise<void>(resolve => { notify = resolve; });
      desktop.output.subscribe(notify);
      let timer: ReturnType<typeof setTimeout> | undefined;
      try {
        const result = await client.observe({ viewIds: ['detail'] });
        if (result.status === 'observed') return result.observation;
        if (result.issue.code === 'SCOPE_UNAVAILABLE') throw Error(result.issue.code);
        await Promise.race([changed, new Promise<never>((_, reject) => {
          timer = setTimeout(() => reject(Error('Snapshot readiness deadline')), Math.max(1, deadline - Date.now()));
        })]);
      } finally {
        desktop.output.unsubscribe(notify);
        if (timer !== undefined) clearTimeout(timer);
      }
    }
    throw Error('Snapshot readiness deadline');
  }
  try {
    const appId = await runtime.installDynamicWorkerApp(desktopId, appUrl, {
      experimentalInteractionModes: modes,
      config: { AOTUI_DATA_DIR: dataDirectory },
    });
    const opened = runtime.experimentalCreateAppScope(desktopId, appId, policy);
    if (opened.status !== 'opened') throw Error(opened.issue.code);
    const observation = await observeReady(opened.client);
    const requests = [
      { name: 'ordinary', input: {} },
      { name: 'parameters', input: { text: 'hello' } },
      { name: 'ref', input: { file: 'file' } },
      { name: 'ref_parameters', input: { file: 'file', text: 'hello' } },
      { name: 'create', input: { relativePath: 'example.txt', content: 'example' } },
    ];
    const outcomes = [];
    for (const [index, request] of requests.entries()) {
      const tool = observation.tools.find(tool => tool.name === request.name);
      const binding = observation.bindings.find(binding => binding.toolId === tool?.id && binding.target.viewId === 'detail');
      if (!binding) throw Error('Tool binding unavailable');
      const result = await opened.client.invoke({ invocationId: `example-${index}`, observationId: observation.observationId,
        bindingId: binding.bindingId, input: request.input });
      if (result.kind !== 'receipt') throw Error(result.code);
      if (result.receipt.outcome.status !== 'succeeded') throw Error(result.receipt.outcome.status);
      outcomes.push(result.receipt.outcome);
    }
    opened.client.close();
    return { modes, outcomes, close: await runtime.beginShutdown().completion };
  } finally {
    await runtime.beginShutdown().completion;
  }
}
```
<!-- b2-example:end -->

创建成功和快照就绪是两个独立事实。示例先订阅原有 `desktop.output`，然后根据实际 `observe` 结果重试，并在失败期限后清理订阅和计时器；期限只限制这次等待。观察不会凭空生成没有来源的数据。

安装选项是可信宿主字段，不能放入 `AppLaunchConfig` 请求授权。只接受 own、可枚举的数据属性和已知唯一模式（五种）；顺序被规范化并复制、冻结。`undefined` 保持旧默认，`[]` 明确不启用，继承字段不授权。非法输入抛出 `INTERACTION_MODES_INVALID`，消息保持 `Invalid experimental interaction modes`。pending→open、关闭后重开和 reinitialize 保留进程内捕获值；序列化 DesktopState 不自动恢复授权，新宿主需要重新提供可信安装选项。

pending、paused、closing 或关闭的父级拒绝新 Scope；running App 被 collapsed 后仍可创建。暂停时旧 Scope 可能观察已保留的来源，但 Host 不派发工具；恢复同一实例遵守原合同。close/delete/reinitialize 永久撤销旧 Scope，旧 observation 不重定向到同 ID 的新实例。外层不具备能力时返回 `SCOPE_UNAVAILABLE`；Worker 没有对应 ACK 时返回 `REF_EXECUTION_UNAVAILABLE`；有效实例上的错误 policy 由 Core 返回 `SCOPE_INVALID`。模式声明不代表旧 SDK Wrapper 获得执行资格。

Runtime、Desktop、App 开始关闭时同栈停止交互。旧 Scope 的 abort 表示已取消受理，真实回调的 finally 尚未结束时，所有者仍保留它。`CloseReport.interactions` 在新默认实现中始终存在：`verified` 表示所有者覆盖可验证，`retainedScopes` 是实际 Scope 数，`retainedBytes` 是 Core 的 `combinedBytes`（JSON/UTF-8 费用）。它不是 RSS、堆内存或性能预算。调用方 deadline 不把真实完成变成释放；Worker、存储、FileCAS 可先开始清理，随后等待同一 authority 的 `whenClosed`。

旧 DI 无新增方法时显式拒绝；旧关闭报告缺少交互字段时标记未知、`resourcesReleased=false`，不会凭空记录业务失败。无法验证的数字不默认为已知零，安全整数溢出截为 `Number.MAX_SAFE_INTEGER` 并标记未知。真实新 Host 管理旧 Worker 的空 Core 仍可验证，原 persistence 的 legacy 兼容语义保留。自定义 DI 声明能力也承担实例身份和关闭合同。

B2 阶段的交付验证使用 Runtime/SDK 实际 tar，在外部标准 node_modules 以公开包名消费；第三方依赖复用归档环境并记录来源。该阶段证明现有依赖装配下的真实入口，不代表完整干净安装或全部平台支持。异步 validator/provider.query 的生命周期证据使用受控 Receiver 配实际 Core，当前 SDK 没有因此新增 provider.query API。外部 detached 工作及仅返回 accepted operation ID 的外部任务不因此被证明已终止。B1 纯 Core/Memory 包消费单独复验；本入口本身不授权 Strict、Full M4、默认 Router 或正式延迟/RSS 预算。

W09-C 的分发验证补充完整的外部 npm install、第二空目录离线 ci、锁与实际安装内容/权限/内部链接对照；它与上文 B2 的既有依赖装配证据分开记录。步骤、逐行二进制兼容边界、工程预算和资源归属见 [分发文档](sdk-runtime-distribution.md)，SDK职责见 [SDK兼容说明](../../sdk/docs/runtime-compatibility.md)。

无legacy TypeTools且inventory/DOM/fragments完整一致的AppKernel支持初始空和最后View卸载后的空V2；空selection仍拒绝。缺inventory方法或孤立DOM拒绝，不能回退V1掩盖失败。legacy/mixed与旧SDK非空DOM无owned View保留V1。新能力仍需Host配置、Worker ACK和逐Binding资格共同成立，旧Wrapper不会自动升级。
