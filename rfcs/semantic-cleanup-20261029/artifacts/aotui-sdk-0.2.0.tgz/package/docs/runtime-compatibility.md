# SDK 与 Runtime 兼容边界

SDK 把开发者的 Preact 组件、View、Ref 和 Tool 声明提交给 Runtime；Runtime 负责身份、来源、授权、执行通道与资源所有权。SDK 的渲染成功、工具声明兼容、Worker 协议支持和某个 Wrapper 可执行是四个不同事实。版本号不能代替实际产物哈希和逐 Binding 检查。

普通 TypeScript 程序可以直接使用 `@aotui/runtime/core` 和 Memory adapter，自己注册 View/Tool、提交 V2 Draft、创建受信任 Scope。需要 Preact 视图和真实 Node Worker 时使用 SDK `createTUIApp`、`View`、`useDataRef`、`experimental_useReadOnlyTool`，由 Host 安装应用并显式选择所需 experimentalInteractionModes。SDK 不创建第二个 Store，也不替代 Host 的可信授权。示例沿用 [Core 文档](../../runtime/docs/core-public-entry.md) 和 [公共应用文档](../../runtime/docs/runtime-app-interaction.md)。

默认的旧 Router/Fragment 路径保持原合同。只保留五种 Scope 模式；ordinary-v2 复用到普通参数读写，旧 Worker 对 mutation 仍明确拒绝。App lifecycle 使用单一 v2 offer/ACK，stop/close 各自可选。旧 Wrapper 在新 Worker 中不会自动升级，旧 Host/Worker 也不会因为接受普通业务声明就拥有新能力。没有对应 ACK 时新入口拒绝；旧 Host 无法表达新调用时为不支持/不可发现。W00 original/rebuilt必须分别测试，W07-B3B旧Wrapper与当前Wrapper共存时也逐目标检查。实际支持的二进制组合、安装步骤与消费环境见 [分发文档](../../runtime/docs/sdk-runtime-distribution.md)、[普通 Tool 与应用清理](tool-lifecycle.md) 及对应交付证据，未测版本不作兼容承诺。

只读参数 default 是注释，省略字段不会自动填入 Handler，业务可以自行默认。Ref首批只接受一个必填顶层、同View owner、只读 snapshot-value 对象；未声明业务refType时可以是真实unknown，声明具体类型时严格比较。Ref-only更新必须更新快照来源，即使DOM文本未变。旧Observation持有原值；跨View/伪造Ref在授权及Handler前拒绝。

新AppKernel在满足完整owned/DOM/fragments集合且无legacy TypeTools时支持合法空V2。初始空、最后View卸载、同ID重新挂载都明确表达；缺接口和孤立DOM不能冒充空集合。legacy/mixed TypeTools以及旧SDK非空DOM无owned View保持V1，失败不降级掩盖错误。空selection仍非法，View/Tool重挂或disable/re-enable不能使旧Binding复活。Handler函数身份变化通常只更新committedHandler；真正重注册须由声明变化或卸载重挂产生，不能靠换函数假定Binding已更新。

关闭/reinitialize永久撤销旧Scope。abort或调用方deadline不证明真实回调结束；父owner等待Core whenClosed、Worker实际退出和存储/IO释放。业务失败保留data/error；终态丢失不自动重试，撤销后结果可能不可见。Core返回对象由调用者持有的生命周期，业务持久值与框架工作资源分别归属。三轮预算、资源额度/归属和实际释放证据见分发文档与W09-C报告。

完整 IDE 的显式 scoped 入口及固定 TypeScript LSP profile 由本轮单独验收，见 IDE 的 SCOPED_IDE.md 与 D6 证据。完整浏览器/Edge、Strict、Full M4、其他 LSP profile 或默认 Router 不从该结果推断准出。

兼容 adapters 的严格类型检查另有 D5 时已复现限制：该次实际安装的 `@ai-sdk/provider` 3.0.19、`ai` 6.0.315、TypeScript 5.9.3、`json-schema` 0.4.0 均未安装 `@types/json-schema`。`@aotui/runtime/adapters` 的 `AOTUIDrivenSource` 引入该声明链，在 `skipLibCheck=false` 下产生两条 TS7016；B2/C 独立对照相同，不能称为全部入口 strict 通过。原 Host 的 `skipLibCheck=true` 消费通过，五组根入口/SDK与纯Core的strict保持不变。决定与证据见 [W09-C-Q02](../../rfcs/sdk-runtime-delivery/w09-c-q02-20261026T200614Z/DECISION.zh-CN.md)。`D-LEGACY-ADAPTER-TYPES-01` 由接任负责人跟踪，沿用既有延期范围，在全 adapters strict 可消费或稳定发布宣称前关闭；本次不以局部入口 strict 通过替代它，也未添加类型 shim。这里只覆盖对应实测依赖组合，不推广其他版本。
