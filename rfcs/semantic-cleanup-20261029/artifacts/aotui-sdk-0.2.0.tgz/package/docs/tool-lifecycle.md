# 普通 Tool 与应用清理

本次收敛复用 `useViewTypeTool`，不再要求普通写操作声明实体 Ref 或使用专用实体 Hook。应用负责业务版本、并发检查和真正完成后才返回成功；SDK 负责把调用交给正确的已提交 Handler，Runtime 负责实例、View、绑定、参数、授权与自身生命周期。

## 普通异步 Tool

在目标 View 内使用现有的三参重载，可选第四参控制 enabled：

```tsx
const [Save] = useViewTypeTool('save', {
  description: 'Save the current document after edits are ready.',
  params: { content: { type: 'string', required: true } },
  isMutating: true,
}, async ({ content }) => {
  await document.save(content); // 应用等待真实写入并检查自己的业务条件。
  return { success: true };
}, { enabled: document.ready });
```

`document` 是应用提供的对象，SDK 不创建或验证其业务协议。普通参数复用既有 B1 捕获/校验规则：不转换类型，不填默认值，默认拒绝额外字段；`additionalProperties: true` 可显式允许额外 JSON 字段。参数和 Handler 在提交时绑定。enabled 位于可选第四参，而不是 options 中。

一般参数/写操作使用 `ordinary-v2`；原空参数只读工具可以继续使用 `ordinary-v1`。显式只读 Hook 和 Ref 工具仍各守原合同。旧四参 type-wide 重载保留旧行为。普通调用不需要顶层 `refId`、`entityType/entityId/entityVersion` 或额外的 `{result: ...}` 包装。

| Handler 返回值 | 含义 |
| --- | --- |
| `{ success: true, data }` | 应用报告操作成功，实际完成时机由应用保证。 |
| `{ success: false, error, effects: 'none' }` | 应用声明失败且没有业务副作用。 |
| `{ success: false, error, data, effects: 'partial' }` | 应用声明失败但已经有部分效果，可用 data 说明已完成项目。 |
| `{ success: false, error, data }` | 未声明副作用；Core 保留原结果并按已有规则报告 unknown。 |
| 抛异常、非法结果、响应丢失 | 不推断没有副作用，不自动重新执行。 |

`effects` 在 ordinary-v2 的失败结果中生效（包括复用该 helper 的参数只读 Hook）；SDK 将它转交给现有终态字段，不把声明当成框架验证。旧 ordinary-v1 与四参 legacy 结果语义保持。常规成功只需一个 `OperationResult`。业务上需要“必须基于版本 N 修改”的应用可自行提供 expectedVersion 参数并校验；普通框架不强制所有应用采用该模型。

当前普通模式保持 App/View/Tool 绑定检查，但同一绑定的业务状态变化不会自动撤销旧 Observation。IDE 的文件和工作区并发守卫继续由 IDE 实现，显示面板变化不再充当语言查询的业务版本。

## 可选清理回调

```tsx
// createTUIApp({ experimentalAppLifecycle: true, component: Root, ... })
experimental_useAppLifecycle({
  stop() { session.stop(); },
  close() { return session.close(); },
});
```

`stop` 与 `close` 各自可选；无回调的应用正常关闭。stop 同步停止应用的新工作；close 可等待应用实际拥有的文件、监听和子进程。已接受的初始化会先汇合；卸载不会丢掉 cleanup 责任。

该 Hook 需要 App 上下文，每个 App 实例至多登记一次。登记它的组件卸载时会启动已登记的 stop/close。建议放在根组件或其他与 App 同寿命的组件中，避免随单个 View 反复挂载。

报告只含 `protocol / instanceId / state / issues`，协议为 `app-lifecycle-v2`。它描述回调完成情况；Runtime 的 `resourcesReleased` 描述 Runtime 实际掌握的资源。失败回调仍被记录，执行器不健康回池；即使随后 Worker 与存储确实释放，关闭也不会被包装成成功。外部进程由创建它的应用清理。

## 迁移与兼容

删除了 `experimental_useVersionedEntityTool`、其结果/资源/Handler 类型、entity-v1 专用 IPC 和能力声明。`useEntityRef` 与 Core 原有实体来源能力没有删除，但普通 Tool 不依赖它们。IDE 入口为 `ideEntryForRoute('scoped')`；默认 legacy 入口保持。

使用同一交付的 Runtime、SDK、IDE tarball。版本号相同不代表历史产物支持新合同：旧 Worker 对普通 mutation 明确拒绝，旧生命周期 v1 与新 v2 不混用，新 opt-in 工厂拒绝缺失端口。旧普通只读工具和未 opt-in 工厂沿用各自旧合同，不自动补授权或降级重试。
