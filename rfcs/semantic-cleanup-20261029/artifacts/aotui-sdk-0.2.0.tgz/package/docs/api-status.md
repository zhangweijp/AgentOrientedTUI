# SDK 根入口：成熟度与实际可用性

本表描述当前接纳实现，**没有给新语义授予整体 stable**。`supported-existing` 是受测组件环境中的已有能力；`experimental` 仍有准确版本、授权和来源限制；`legacy-compatible` 保留旧行为；`static-export / not-verified` 只说明实际产物导出了名字。运行环境条件与成熟度分别列出。

W07/W08/W09 已签署 D5 的范围保持。本轮收敛为普通 View-local Tool、可选 App 清理回调和完整 IDE 显式入口；新能力仍 experimental，准出范围以本轮 D6 证据为准。旧 ParamDef 与新合同并存，不破坏性统一。

C01 删除了无实际能力的过渡入口及无消费者的状态便利 Hook、命名校验工具。下表只列当前根入口；删除项的迁移去向见 [迁移说明](migration.md)。这不表示后续 Semantic 清理批次或项目所有者验收已经完成。

## 值 export 的状态

| 精确名称 | 成熟度 | 可用条件与证据边界 |
|---|---|---|
| createTUIApp, View, AppRuntimeContext | supported-existing | 当前 Preact 组件 Runtime；app_name 为符合规则的字符串，Runtime 调用 initializeComponent。View/Ref 组件装配有实际测试。factory.create 方法本身 deprecated 且抛错；不是整个工厂被弃用。 |
| useState, useCallback, useEffect, useMemo, useReducer, useRef | supported-existing | Preact Hook 重导出，服从 Preact 组件 Hook 规则。useRef 是 Preact Hook，未弃用。 |
| useAppRuntimeContext, useViewContext, useAppConfig, useAppEnv, useRefRegistry | supported-existing | 使用已有组件上下文；配置/元数据和引用注册不代表任意 Host 注入能力均已验收。 |
| useDataRef, useArrayRef | supported-existing | 组件 View 内注册数据 Ref。发布 Ref 不授予执行许可；useArrayRef 也不意味着单对象 Ref 工具可接受数组。 |
| experimental_useReadOnlyTool | experimental | ordinary-v2 或 snapshot-value-v2 准确协商及对应私有资格；B1/B3B 校验、Scope 来源和 Controller 授权；单必填顶层同 owner 只读对象 Ref。 |
| experimental_useCreateIfAbsentTool | experimental | 仅已验收的 create-if-absent 及受信 Controller／资源前置条件，不代表任意写入已支持。 |
| useViewTypeTool | experimental（三参 local）；legacy-compatible（四参 type-wide及旧参数路径） | 三参绑定父 View，普通参数/写操作复用 ordinary-v2 与 B1 合同；空参数只读保留 ordinary-v1。四参 type-wide 仍沿旧行为；旧私有包装不自动获得新资格。 |
| experimental_useAppLifecycle | experimental | factory 显式 opt-in；stop/close 各自可选，无回调正常关闭；同步 stop 先于 seal/flush；close 可等待应用工作。旧 SDK 保持 legacy-unverified。 |
| useEntityRef | experimental | 当前组件发布版本化实体 Ref；不自动授权修改，也不自行读取磁盘版本。 |
| useLLMOutputChannel, useLLMOutputHistory | supported-existing，环境条件可用 | 见下表。组件接收/受控 Provider 有测试，不等于 Agent Driver、模型调用或新 Provider 协议已实现。 |
| defineParams | legacy-compatible | 宽 ParamDef 声明与旧校验，不是新合同全部能力的保证。 |
| usePersistentState | experimental | 实际支持 state-session-v1 的 SDK factory 与 Runtime 实例端口；严格 JSON、提交期绑定、实例 flush/clear/关闭。已签署 W08/D5 范围保持；新业务 owner 两阶段停发/清理由 W10 增加，见 [persistence](persistence.md)。 |
| TUI_FACTORY, createCallableFactory, isFactory, isAppFactory, isViewFactory, createInlineView, hasMountableSupport | legacy-compatible / static-export | 既有工厂、适配及形状检查辅助，保留当前实现；本批没有给每种外部使用方式作独立验收。旧 View 形状检查不能替代当前组件能力判断。 |
| AOTUIError, escapeHtml, escapeJsonForAttr | legacy-compatible / static-export | 保留错误与格式化辅助；不是新的语义执行／错误层级合同。未逐项验证的外部组合标为 not-verified。 |

## 组件环境与明确错误

| API/情形 | 实际行为 |
|---|---|
| 四参 useViewTypeTool，enabled=true而缺少typeTools | SDK_TYPE_TOOLS_UNAVAILABLE；不能假装注册成功。enabled=false不需要缺失能力。 |
| LLM live，有实际可调用Provider.subscribe | 只订阅该Provider；更换清理旧源、卸载取消，Provider异常原样传播，不降级DOM。 |
| LLM live，无Provider但有document | 只监听aotui:llm-output与aotui:llm-text；支持content/reasoning/usage-only，Root可位于View外。无历史缓存。 |
| LLM live，无Provider/document，或Provider.subscribe无效 | SDK_LLM_OUTPUT_UNAVAILABLE；无效Provider不静默回退。 |
| LLM history，有实际Provider.getHistory | 原样查询；空数组是合法结果，异常原样传播。宿主使用既有Context集成，不新增公共Provider装配API。 |
| LLM history，无Provider或getHistory无效 | SDK_LLM_HISTORY_UNAVAILABLE；组件DOM桥不提供历史，不能用假空数组替代。 |
| includeHistory非undefined，包括true/false/null | SDK_LLM_HISTORY_OPTION_UNSUPPORTED；保留deprecated类型字段用于迁移诊断。省略/undefined时DOM接后续事件，Provider保留自身重放策略；SDK不重放/去重。 |
| app_name缺失、仅name或非string | 明确配置错误；先检查类型，再应用原正则，禁止借字符串转换通过。 |

## 根入口精确名称清单

以下清单列出当前源码根入口，声明产物与实际 JavaScript namespace 需在本轮新构建中一并核对。本轮保留可选清理 Hook，并将普通 Tool 收敛到既有 Hook。AOTUIError 同时是值与类型。类型的成熟度随对应职责，不独立授予运行能力：普通/Ref/创建合同类型为 experimental；宽ParamDef、旧Factory/Runtime类型为兼容描述；组件与LLM类型仍有上述环境条件。`LLMOutputChannelOptions` 仅其 includeHistory 字段 deprecated，不是根 useRef 或全部LLM接收能力弃用。

值 export：

```text
AOTUIError, AppRuntimeContext, TUI_FACTORY, View,
createCallableFactory, createInlineView, createTUIApp, defineParams, escapeHtml,
escapeJsonForAttr, experimental_useCreateIfAbsentTool, experimental_useReadOnlyTool,
experimental_useAppLifecycle,
hasMountableSupport, isAppFactory, isFactory, isViewFactory,
useAppConfig, useAppEnv, useAppRuntimeContext, useArrayRef, useCallback, useDataRef,
useEffect, useEntityRef, useLLMOutputChannel,
useLLMOutputHistory, useMemo, usePersistentState,
useReducer, useRef, useRefRegistry, useState,
useViewContext, useViewTypeTool
```

类型 export：

```text
AOTUIError, AppContext, AppID, AppReinitializeContext, AppRuntimeContextValue,
ArrayRefHandle, CreateIfAbsentHandler, CreateIfAbsentOutcome, CreateIfAbsentTerminal,
CreateIfAbsentToolOptions, DesktopID, Factory, FactoryType, IAOTUIApp, IAppConfig,
ILLMOutputChannelContext, IRefRegistry, IViewMeta, InferArgs,
InlineViewConfig, ItemRefFormatter, LLMOutputChannelOptions, LLMOutputEvent,
LLMOutputListener, ListRefFormatter, OperationError, OperationID, OperationResult,
OrdinaryParamDef, OrdinaryParams, ParamBaseType, ParamConstraints, ParamDef,
ParamSchema, ParamType, ReadOnlyParams, ReadOnlyToolArgs, ReadOnlyToolHandler,
ReadOnlyToolOptions, RefHandle, RequiredStringArgs, RequiredStringParams,
SnapshotID, SnapshotValueRefParamDef, TUIAppConfig, TUIComponentAppFactory,
TypeToolHandler, TypeToolOptions, TypeToolUI, UseViewTypeToolResult, ViewID, ViewProps,
AppStatePersistence, StateBindingStatus, StateFlushReport, StateValue, StateIssue,
PersistOptions, PersistStatus, PersistMeta, AppLifecycleCallbacks
```

文档中的“真实组件”“真实Worker”“受控Provider”“纯类型/静态清单”是不同证据等级。实际 token-monitor Root DOM 消费检查不签 W09 分发；中性 Core 图不代表整个 npm 包可移植。handler业务unknown且entered-returned可以与健康传输并存，不能仅看unknown字符串推断Worker失联。

持久化组合协商、缺失端口及已删除全局入口的迁移见 [persistence](persistence.md)。新协议仍 experimental，接任阶段由同一负责人开发、测试、自查和验收，不称独立验收。

入口见 [SDK README](../README.md)，完整分批迁移见 [migration](migration.md)，已接纳普通/Ref示例见 [ordinary-v2](ordinary-v2.md)和[readonly-ref-v2](readonly-ref-v2.md)。
