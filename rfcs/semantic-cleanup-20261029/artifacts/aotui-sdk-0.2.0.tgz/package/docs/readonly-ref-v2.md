# 实验性只读工具：引用原始快照值

状态仍为 experimental；根入口和环境要求见 [SDK README](../README.md)，精确名称及迁移差异见 [API 状态](api-status.md)与[迁移说明](migration.md)。本页完整示例和已验收参数语义保持。

`experimental_useReadOnlyTool` 同时支持普通参数和一个必填、顶层的对象Ref。调用输入的Ref是页面展示的字符串ID，handler收到原始观察快照中的只读JSON对象；普通字段使用与普通工具相同的B1规则。

下面是完整应用，所有SDK能力从根入口导入。`useDataRef`发布当前值并显示引用；工具不修改数据，结果指向已有详情View。Root只列出实际挂载的View及工具。

```tsx
import { h } from 'preact';
import { createTUIApp, View, useDataRef, experimental_useReadOnlyTool } from '@aotui/sdk';

function FileDetail() {
  const file = useDataRef('sample_file', {
    title: 'Example file',
    lines: ['First line', 'Second line'],
  });
  const [Inspect] = experimental_useReadOnlyTool('inspect_file', {
    description: 'When to use: inspect a displayed file value. How to use: provide its Ref ID and choose summary or full.',
    params: {
      file: { type: 'reference', required: true, refSource: 'snapshot-value-v1' },
      format: { type: 'enum', options: ['summary', 'full'], required: true },
    },
  }, ({ file, format }) => {
    const title = typeof file.title === 'string' ? file.title : 'Untitled';
    return {
      success: true,
      data: { view_id: 'detail', title, format, keys: Object.keys(file) },
    };
  });
  return h('section', {}, [
    h('h2', {}, 'Example file'),
    h('p', {}, file('Original file value')),
    h(Inspect, { children: 'Inspect file' }),
  ]);
}

function App() {
  return h('main', {}, [
    h(View, { id: 'root', type: 'Root' }, [
      h('h1', {}, 'File Inspector Application Instruction'),
      h('h2', {}, 'What File Inspector is'),
      h('p', {}, 'Inspect values displayed in File Detail.'),
      h('h2', {}, 'How to use File Inspector'),
      h('p', {}, 'Use the displayed reference with inspect_file and read its result.'),
      h('h2', {}, 'Views of File Inspector'),
      h('h3', {}, 'File Detail'),
      h('h4', {}, 'File Detail Instruction'),
      h('p', {}, 'Displays the current file value and its reference.'),
      h('h4', {}, 'File Detail Available Tools'),
      h('p', {}, 'inspect_file'),
    ]),
    h(View, { id: 'detail', type: 'FileDetail' }, h(FileDetail, {})),
  ]);
}

export default createTUIApp({ app_name: 'file_inspector', component: App });
```

本例使用 `useDataRef` 的实际unknown业务类型，所以没有声明具体refType。handler把对象字段视为unknown并检查类型；refType不提供业务结构推断。声明具体refType时，原Ref描述符必须严格匹配；Ref必须属于原目标View实例，且payload是非null、非数组的普通JSON对象。

`ReadOnlyParams`与`SnapshotValueRefParamDef`已从SDK根入口导出；`OrdinaryParams`继续只描述普通字段。Ref要求required:true、refSource:snapshot-value-v1，不允许default、constraints、options或itemType。恰好一个Ref由运行时编译保证。handler参数递归只读；default只是声明注释，不补值、不转换类型、不trim或删除额外字段。默认拒绝额外参数，显式additionalProperties:true可保留。

部署方需让受信Controller显式启用snapshotShadow、experimentalReadOnlyViewTools和experimentalInteractionModes中的snapshot-value-v2。公开参数标记为snapshot-value-params-v1，Wire capability为view-tool-ref-invoke/v2；单有声明或端口支持不能执行。应用作者无需管理observationId或Worker身份，Controller负责观察、绑定、授权和调用。旧Ref V1保持原规则，新profile遇旧能力会拒绝。

完整参数与展开payload受24层、10000节点及128KiB约束，最终执行还受Core请求、Ref envelope、Snapshot和整IPC的交集限制。类型检查或单次参数验证不证明来源或权限，也不替代实际Worker资格。
