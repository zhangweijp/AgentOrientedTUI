# 按能力迁移 SDK 调用

普通参数与写操作使用现有三参 useViewTypeTool；显式只读/单对象 Ref 保留 experimental_useReadOnlyTool，限定条件创建保留 experimental_useCreateIfAbsentTool。删除实体专用 Hook；experimental_useAppLifecycle 的 stop/close 各自可选，协议为 v2。需要匹配产物；旧 wrapper 不自动升级。完整合同与 IDE 迁移见 [普通 Tool 与应用清理](tool-lifecycle.md) 和 IDE 的 SCOPED_IDE.md。

以下完整应用对照历史 D5 SDK 的参数路径与新合同。迁移前示例描述旧 SDK 产物的三参 View-local `useViewTypeTool` 行为；当前 SDK 在支持 ordinary-v2 的 Runtime 上运行同一普通参数示例时，会进入 B1 合同，不能再用它重现下表的 legacy 规则。真正保留旧行为的四参 type-wide 重载仍需要 `typeTools` 上下文并自行声明目标参数。

## 迁移前：历史 D5 SDK 参数路径

```tsx
import { h } from 'preact';
import { createTUIApp, View, useState, defineParams, useViewTypeTool } from '@aotui/sdk';

function SummaryContent() {
    const [last, setLast] = useState('No result');
    useViewTypeTool('inspect', {
        description: 'When to use: inspect the displayed summary. How to use: supply choice and a short text.',
        isMutating: false,
        params: defineParams({
            choice: { type: 'enum', options: ['7', 'ok'], required: true },
            text: { type: 'string', required: true, constraints: { maxLength: 1 } },
            limit: { type: 'number', default: 2 },
        }),
    }, async (args) => {
        setLast(JSON.stringify({ choice: args.choice, text: args.text }));
        return { success: true, data: { view_id: 'summary', choice: args.choice, text: args.text,
            has_extra: Object.hasOwn(args, 'extra'), has_limit: Object.hasOwn(args, 'limit') } };
    });
    return <p>{last}</p>;
}

function AppRoot() {
    return <>
        <View id="root" type="Root" name="Root">
            <h1>Summary Application Instruction</h1>
            <h2>What Summary is</h2><p>Inspect the current summary.</p>
            <h2>How to use Summary</h2><p>Call inspect and read the summary View.</p>
            <h2>Views of Summary</h2><h3>Summary</h3>
            <h4>Summary Instruction</h4><p>Shows the last inspection result.</p>
            <h4>Summary Available Tools</h4><ul><li>inspect</li></ul>
        </View>
        <View id="summary" type="Summary" name="Summary"><SummaryContent /></View>
    </>;
}

export default createTUIApp({ app_name: 'summary_legacy', component: AppRoot });
```

## 迁移后：统一普通只读参数合同

```tsx
import { h } from 'preact';
import { createTUIApp, View, useState, experimental_useReadOnlyTool } from '@aotui/sdk';

function SummaryContent() {
    const [last, setLast] = useState('No result');
    experimental_useReadOnlyTool('inspect', {
        description: 'When to use: inspect the displayed summary. How to use: supply a declared choice and one Unicode code point.',
        params: {
            choice: { type: 'enum', options: ['7', 'ok'], required: true },
            text: { type: 'string', required: true, constraints: { maxLength: 1 } },
            limit: { type: 'number', default: 2 },
        },
    }, (args) => {
        setLast(JSON.stringify({ choice: args.choice, text: args.text }));
        return { success: true, data: { view_id: 'summary', choice: args.choice, text: args.text,
            has_extra: Object.hasOwn(args, 'extra'), has_limit: Object.hasOwn(args, 'limit') } };
    });
    return <p>{last}</p>;
}

function AppRoot() {
    return <>
        <View id="root" type="Root" name="Root">
            <h1>Summary Application Instruction</h1>
            <h2>What Summary is</h2><p>Inspect the current summary.</p>
            <h2>How to use Summary</h2><p>Call inspect and read the summary View.</p>
            <h2>Views of Summary</h2><h3>Summary</h3>
            <h4>Summary Instruction</h4><p>Shows the last inspection result.</p>
            <h4>Summary Available Tools</h4><ul><li>inspect</li></ul>
        </View>
        <View id="summary" type="Summary" name="Summary"><SummaryContent /></View>
    </>;
}

export default createTUIApp({ app_name: 'summary_contract', component: AppRoot });
```

## 已知行为变化

| 输入 | 旧普通参数路径 | 新合同 |
|---|---|---|
| `{ choice: 'ok', text: 'a' }` | 正常执行 | 正常执行 |
| choice=7，options 含字符串 '7' | enum 比较字符串形式，handler 仍收到原值 | 严格比较，拒绝数字，不做转换 |
| text='😀'，maxLength=1 | 旧 UTF-16 长度判断拒绝 | 一个 Unicode code point，允许 |
| 附加 extra | 保留额外字段 | 默认闭合，拒绝；开放需要声明 additionalProperties |
| 缺席 limit，声明 default=2 | 不自动填充 | 不自动填充 |

TypeScript 会提前阻止一部分错误 JS 输入，运行时仍需验证模型/JSON 调用。旧宽 `ParamDef`/`defineParams` 不是新合同的所有能力承诺。新普通规则只来自 Runtime B1，Ref 组合来自 B3B，SDK 不复制规则。

## Ref 与创建工具的条件

单对象快照 Ref 完整应用见 [readonly-ref-v2](readonly-ref-v2.md)。它需要必填顶层 reference、`refSource: 'snapshot-value-v1'`、同 View owner 和对应 Runtime/Worker 私有资格。Core 来源模式、声明 profile、Wire mode 是不同职责；应用继续只写参数和 handler。无业务 refType 时保留真实 unknown，具体声明严格比较。旧 Wrapper 不因 Worker 升级自动获得新资格。

条件创建入口只适用受信授权下的 create-if-absent 及其已验收资源前置条件。其他任意文件写入没有因此获准。readonly 是行为声明，不能替代权限或来源检查。

## 结果、环境与弃用项

handler 返回业务 OperationResult 或条件创建 outcome；Controller 另有来源、执行阶段、可见性和回执。可信 entered-returned 中的业务结果可以映射为 unknown，同时传输仍健康。不能用结果字符串判断 Worker 是否可复用；传输无法确认时的 unknown 才触发五模式＋两个 View-owned 兼容入口的停发／不回池边界。

缺少旧 typeTools 且启用四参注册时，SDK_TYPE_TOOLS_UNAVAILABLE 明确拒绝。组件通过状态决定是否渲染 `<View>`，以挂载和卸载控制页面生命周期。LLM DOM 只接后续事件，不提供 history；实际 Provider 可提供自己的历史。删除 includeHistory 的 true 和 false，均会报 SDK_LLM_HISTORY_OPTION_UNSUPPORTED；省略/undefined 不改变来源自身策略。

使用 `app_name` 字符串替代旧示例误写的 name。Runtime 使用 initializeComponent；factory.create() 保留 deprecated 拒绝。

C01 的 Breaking Changes：

- 删除 `persistenceManager` 及其全局注册/保存类型。使用 `usePersistentState` 和当前 `useAppRuntimeContext().persistence.flush()`，检查本次保存报告。
- 删除 `useMountableViewRegistry/useDynamicViewRegistry`、对应类型以及组件 Context 中仅抛错的字段。通过组件状态挂载或卸载 `<View>`。
- 删除 `useResourceRef` 过渡别名，数据引用统一使用 `useDataRef/useArrayRef`。根 `useRef` 仍是 Preact Hook。
- 删除 `useSignalStore` 及其 `SignalStore` 类型，组件状态使用现有 `useState/useReducer`。
- 删除根入口的 `assertValidOperationName/validateAppId/validateViewId/validateOperationName/validateFunctionName`。View 与 Runtime 必需的身份、输入和来源校验仍由各自正式契约执行。

这些删除不代表 type-wide、旧执行协议和其他实验能力已经退出；它们的当前可用范围仍按本文及 API 状态说明。

完整名称和条件见 [API 状态](api-status.md)，入口见 [SDK README](../README.md)。独立分发、关闭排空/flush、产品延迟/RSS和整体稳定承诺未由这一迁移授予。
